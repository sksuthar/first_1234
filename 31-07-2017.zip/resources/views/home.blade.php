@extends('layouts.app')

@section('content')    
<div class="container application-base">
    <div class="row">
        fasd
    </div>    
</div>
@stop 