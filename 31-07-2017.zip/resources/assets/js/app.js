'use strict';


var app = angular.module('wizboat-app', ['wizboat.controllers']);

