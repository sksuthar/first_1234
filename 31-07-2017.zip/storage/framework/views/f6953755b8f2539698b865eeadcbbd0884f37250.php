<?php $__env->startSection('content'); ?>
    <style>
        .form-inline .form-control{
            width: 100%;
        }
    </style>

    <div class=" home-page-bg bg-img-fit">
        <div class="row pad-up-down wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
            <div class="col-xs-12">
                <?php echo Form::open(['files'=>true, 'method'=>'get', 'url'=>'/home/search','enctype' => 'multipart/form-data']); ?>

                <div class="col-md-3 col-sm-3  col-xs-3 pad0">
                    <select class="marg pad-in width-full custom-select form-select  brd-a-2-green" id="inlineFormCustomSelect" name="state">
                        <option value="">Select State</option>
                        <?php foreach($state as $row): ?>
                            <option value="<?php echo e($row->state_id); ?>"><?php echo e($row->getstate->state_name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-3 pad0 marg2">
                    <div class="input-group width-full m13-bot">
                        <select class=" width-full pad-in custom-select form-select  brd-a-2-green" id="inlineFormCustomSelect" name="city">
                            <option value="">Select City</option>
                            <option value="1">Mumbai</option>
                            <option value="2">Pune</option>
                            <option value="3">Jodhpur</option>
                            <option value="4">Jaipur</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 col-sm-5 col-xs-11 pad0">
                    <input type="text" class="bot13 pad-in form-control form-text brd-a-2-green" id="title" name="school" placeholder="Search for Schools and Colleges..">
                </div>
                <div class="col-md-2 col-sm-2 col-xs-11 pad0">
                    <button type="text" class="bot13 pad-in btn btn-primary form-text brd-a-2-green">Search</button>
                </div>
                <div class="col-xs-12 wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                    <p class="home-text">Book your seats in school or college<br> or applying through this</p>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>


    </div>
    <div class="container">


        <div class="row padhome">
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="1">
                <a href="category/celebrity" class="">
                </a><div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');"><a href="category/celebrity" class="">
                    </a><div class="cuadro_intro_hover"><a href="category/celebrity" class="">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                        </a><div class="caption"><a href="category/celebrity" class="">
                                <div class="blur"></div>
                            </a><div class="caption-text"><a href="category/celebrity" class="">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Celebrities</h1>
                                        </div>
                                    </div>
                                </a><ul class="list-unstyled home-cat-sub-cat"><a href="category/celebrity" class="">
                                    </a><li><a href="category/celebrity" class=""></a><a href="category/celebrity/bollywood" class="dropdown-nav-menu-li">Bollywood</a></li>
                                    <li><a href="category/celebrity/south-film-industry" class="dropdown-nav-menu-li">South Film Industry</a></li>
                                    <li><a href="category/celebrity/bhojpuri-film-industry" class="dropdown-nav-menu-li">Bhojpuri Film Industry</a></li>
                                    <li><a href="category/celebrity/tv-artists" class="dropdown-nav-menu-li">TV Artists</a></li>
                                    <li><a href="category/celebrity/page-3" class="dropdown-nav-menu-li">Page 3</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><!-- artist-signup-category-div -->

            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="2">
                <a href="category/athletes" class="">
                </a><div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');"><a href="category/athletes" class="">
                    </a><div class="cuadro_intro_hover"><a href="category/athletes" class="">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                        </a><div class="caption"><a href="category/athletes" class="">
                                <div class="blur"></div>
                            </a><div class="caption-text"><a href="category/athletes" class="">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Athletes</h1>
                                        </div>
                                    </div>
                                </a><ul class="list-unstyled home-cat-sub-cat"><a href="category/athletes" class="">
                                    </a><li><a href="category/athletes" class=""></a><a href="category/athletes/cricketer" class="dropdown-nav-menu-li">Cricketer</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><!-- artist-signup-category-div -->

            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="3">
                <a href="category/music" class="">
                </a><div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');"><a href="category/music" class="">
                    </a><div class="cuadro_intro_hover"><a href="category/music" class="">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                        </a><div class="caption"><a href="category/music" class="">
                                <div class="blur"></div>
                            </a><div class="caption-text"><a href="category/music" class="">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Music</h1>
                                        </div>
                                    </div>
                                </a><ul class="list-unstyled home-cat-sub-cat"><a href="category/music" class="">
                                    </a><li><a href="category/music" class=""></a><a href="category/music/bands" class="dropdown-nav-menu-li">Bands</a></li>
                                    <li><a href="category/music/djs" class="dropdown-nav-menu-li">DJs</a></li>
                                    <li><a href="category/music/singers" class="dropdown-nav-menu-li">Singers</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><!-- artist-signup-category-div -->

            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="4">
                <a href="category/event-organizers" class="">
                </a><div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');"><a href="category/event-organizers" class="">
                    </a><div class="cuadro_intro_hover"><a href="category/event-organizers" class="">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                        </a><div class="caption"><a href="category/event-organizers" class="">
                                <div class="blur"></div>
                            </a><div class="caption-text"><a href="category/event-organizers" class="">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Event Organizers</h1>
                                        </div>
                                    </div>
                                </a><ul class="list-unstyled home-cat-sub-cat"><a href="category/event-organizers" class="">
                                    </a><li><a href="category/event-organizers" class=""></a><a href="category/event-organizers/wedding-planners" class="dropdown-nav-menu-li">Wedding Planners</a></li>
                                    <li><a href="category/event-organizers/event-planners" class="dropdown-nav-menu-li">Event Planners</a></li>
                                    <li><a href="category/event-organizers/party-planners" class="dropdown-nav-menu-li">Party Planners</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><!-- artist-signup-category-div -->

            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="5">
                <a href="category/emcees" class="">
                    <div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');">
                        <div class="cuadro_intro_hover">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                            <div class="caption">
                                <div class="blur"></div>
                                <div class="caption-text">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Emcees</h1>
                                        </div>
                                    </div>
                                    <ul class="list-unstyled home-cat-sub-cat">
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div><!-- artist-signup-category-div -->
                </a>
            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="6">
                <a href="category/comics" class="">
                    <div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');">
                        <div class="cuadro_intro_hover">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                            <div class="caption">
                                <div class="blur"></div>
                                <div class="caption-text">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Comedy</h1>
                                        </div>
                                    </div>
                                    <ul class="list-unstyled home-cat-sub-cat">
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div><!-- artist-signup-category-div -->
                </a>
            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="7">
                <a href="category/dance" class="">
                </a><div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');"><a href="category/dance" class="">
                    </a><div class="cuadro_intro_hover"><a href="category/dance" class="">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                        </a><div class="caption"><a href="category/dance" class="">
                                <div class="blur"></div>
                            </a><div class="caption-text"><a href="category/dance" class="">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Dance</h1>
                                        </div>
                                    </div>
                                </a><ul class="list-unstyled home-cat-sub-cat"><a href="category/dance" class="">
                                    </a><li><a href="category/dance" class=""></a><a href="category/dance/performers" class="dropdown-nav-menu-li">Performers</a></li>
                                    <li><a href="category/dance/choreographers" class="dropdown-nav-menu-li">Choreographers</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><!-- artist-signup-category-div -->

            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="8">
                <a href="category/models" class="">
                    <div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');">
                        <div class="cuadro_intro_hover">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                            <div class="caption">
                                <div class="blur"></div>
                                <div class="caption-text">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Models</h1>
                                        </div>
                                    </div>
                                    <ul class="list-unstyled home-cat-sub-cat">
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div><!-- artist-signup-category-div -->
                </a>
            </div><!-- col-md-2 category p-a-10 -->
            <!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="9">
                <a href="category/variety-artists" class="">
                </a><div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');"><a href="category/variety-artists" class="">
                    </a><div class="cuadro_intro_hover"><a href="category/variety-artists" class="">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                        </a><div class="caption"><a href="category/variety-artists" class="">
                                <div class="blur"></div>
                            </a><div class="caption-text"><a href="category/variety-artists" class="">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Variety Artists</h1>
                                        </div>
                                    </div>
                                </a><ul class="list-unstyled home-cat-sub-cat">
                                    <a href="category/variety-artists" class="">
                                    </a><li><a href="category/variety-artists" class=""></a><a href="category/variety-artists/bartenders" class="dropdown-nav-menu-li">Bartenders</a></li>
                                    <li><a href="category/variety-artists/photographers" class="dropdown-nav-menu-li">Photographers</a></li>
                                    <li><a href="category/variety-artists/magiciansillusionists" class="dropdown-nav-menu-li">Magicians/Illusionists</a></li>
                                    <li><a href="category/variety-artists/hair-stylists-make-up-artists" class="dropdown-nav-menu-li">Hair Stylists &amp; Make-up Artists</a></li>
                                    <li><a href="category/variety-artists/other" class="dropdown-nav-menu-li">Other</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><!-- artist-signup-category-div -->

            </div><!-- col-md-2 category p-a-10 -->
            <div class=" col-md-2 col-sm-4 col-xs-6 p-a-0 brd-a-2-orange home-category-div" data-cat-id="9">
                <a href="category/variety-artists" class="">
                </a><div class="bg-img-fit" style="background-image: url('http://localhost/bizz/resources/assets/img/home.jpeg');"><a href="category/variety-artists" class="">
                    </a><div class="cuadro_intro_hover"><a href="category/variety-artists" class="">
                            <p style="text-align:center; margin-top:20px;">
                            </p>
                        </a><div class="caption"><a href="category/variety-artists" class="">
                                <div class="blur"></div>
                            </a><div class="caption-text"><a href="category/variety-artists" class="">
                                    <div class="bg-trans-grey">
                                        <div class="artist-signup-title text-center">
                                            <h1 class="font-16 font-500 col-white BebasNeue-Bold letter-space-2 m-t-0 m-b-0 article-tag">Variety Artists</h1>
                                        </div>
                                    </div>
                                </a><ul class="list-unstyled home-cat-sub-cat">
                                    <a href="category/variety-artists" class="">
                                    </a><li><a href="category/variety-artists" class=""></a><a href="category/variety-artists/bartenders" class="dropdown-nav-menu-li">Bartenders</a></li>
                                    <li><a href="category/variety-artists/photographers" class="dropdown-nav-menu-li">Photographers</a></li>
                                    <li><a href="category/variety-artists/magiciansillusionists" class="dropdown-nav-menu-li">Magicians/Illusionists</a></li>
                                    <li><a href="category/variety-artists/hair-stylists-make-up-artists" class="dropdown-nav-menu-li">Hair Stylists &amp; Make-up Artists</a></li>
                                    <li><a href="category/variety-artists/other" class="dropdown-nav-menu-li">Other</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><!-- artist-signup-category-div -->

            </div><!-- col-md-2 category p-a-10 -->
        </div>


    </div>






    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="text-center">
                    <h2>Multi Purpose Theme</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu<br>
                        vestibulum volutpat libero sollicitudin vitae Curabitur ac aliquam <br>
                        lorem sit amet scelerisque justo</p>
                </div>
                <hr>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="box">
                <div class="col-md-4">
                    <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="0.4s">
                        <h4>Responsive</h4>
                        <div class="icon">
                            <i class="fa fa-heart-o fa-3x"></i>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu libero</p>
                        <div class="ficon">
                            <a href="#" class="btn btn-default" role="button">Read more</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="1.0s">
                        <h4>Multi Purpose</h4>
                        <div class="icon">
                            <i class="fa fa-desktop fa-3x"></i>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu libero</p>
                        <div class="ficon">
                            <a href="#" class="btn btn-default" role="button">Read more</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="1.6s">
                        <h4>Easy Customize</h4>
                        <div class="icon">
                            <i class="fa fa-location-arrow fa-3x"></i>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu libero</p>
                        <div class="ficon">
                            <a href="#" class="btn btn-default" role="button">Read more</a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="text-center">
                    <h2>Galleries</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu<br>
                        vestibulum volutpat libero sollicitudin vitae Curabitur ac aliquam <br>
                    </p>
                </div>
                <hr>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="grid">
            <figure class="effect-zoe">
                <img src="<?php echo e(asset('resources/assets/img/25.jpg')); ?>" alt="img25"/>
                <figcaption>
                    <h2>Title <span>Name</span></h2>
                    <p class="icon-links">
                        <a href="#"><span class="icon-heart"></span></a>
                        <a href="#"><span class="icon-eye"></span></a>
                        <a href="#"><span class="icon-paper-clip"></span></a>
                    </p>
                    <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
                </figcaption>
            </figure>
            <figure class="effect-zoe">
                <img src="<?php echo e(asset('resources/assets/img/26.jpg')); ?>" alt="img26"/>
                <figcaption>
                    <h2>Title <span>Name</span></h2>
                    <p class="icon-links">
                        <a href="#"><span class="icon-heart"></span></a>
                        <a href="#"><span class="icon-eye"></span></a>
                        <a href="#"><span class="icon-paper-clip"></span></a>
                    </p>
                    <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
                </figcaption>
            </figure>
        </div>
    </div>

    <div class="content">
        <div class="grid">
            <figure class="effect-zoe">
                <img src="<?php echo e(asset('resources/assets/img/26.jpg')); ?>" alt="img27"/>
                <figcaption>
                    <h2>Title <span>Name</span></h2>
                    <p class="icon-links">
                        <a href="#"><span class="icon-heart"></span></a>
                        <a href="#"><span class="icon-eye"></span></a>
                        <a href="#"><span class="icon-paper-clip"></span></a>
                    </p>
                    <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
                </figcaption>
            </figure>
            <figure class="effect-zoe">
                <img src="<?php echo e(asset('resources/assets/img/26.jpg')); ?>" alt="img30"/>
                <figcaption>
                    <h2>Title <span>Name</span></h2>
                    <p class="icon-links">
                        <a href="#"><span class="icon-heart"></span></a>
                        <a href="#"><span class="icon-eye"></span></a>
                        <a href="#"><span class="icon-paper-clip"></span></a>
                    </p>
                    <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
                </figcaption>
            </figure>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>