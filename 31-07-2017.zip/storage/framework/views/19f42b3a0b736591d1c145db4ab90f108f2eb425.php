<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .form-group.required .control-label:after {
            content:"*";
            color:red;
        }
        .td_1{
            width: 15%;
        }
        .td_2{
            width: 27%;
        }
    </style>
    <div class="container">
        <div class="row center-back">
        <div class="row">
            <div class="col-sm-3 sol-md-3" style="margin-top: 64px; padding:25px; border: 1px solid #DDD; margin-right: 5px;">
                <div class="row">
                    <a href="http://localhost/wi/27-06-2017/application_list/search/436">  
                       <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                           1. Master Of Computer Application
                       </div>
                    </a>
                </div>
                <div class="row">
                    <a href="http://localhost/wi/27-06-2017/application_list/search/436">  
                       <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                           2. Master Of Computer Application
                       </div>
                    </a>
                </div>   
                <div class="row">
                    <a href="http://localhost/wi/27-06-2017/application_list/search/436">  
                       <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                           3. Master Of Computer Application
                       </div>
                    </a>
                </div>   
            </div>
            
            
            
            <div class="col-sm-8 sol-md-8" style="padding:25px;">
                Admision Status                      
                  <div style="border: 1px solid #DDD;  padding-bottom:30px; ">
                   <?php foreach($class_data[0]->getadmissiondate as $row): ?>
                   <?php echo Form::open(['files'=>true, 'method'=>'POST', 'url'=>"/active-admissions/$class_hash/$course_id/update",'enctype' => 'multipart/form-data']); ?>

                   <input type="hidden" name="_c_h" value="<?php echo e($class_hash); ?>" >
                   <input type="hidden" name="_co_i" value="<?php echo e($course_id); ?>" >
                   <input type="hidden" name="a_d" value="<?php echo e($row->id); ?>" >
                   <div class="modal-body">
               
                   
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <label class="control-label" for="password">Open Admission:</label>
                            <div class="input-group date " id="start_ad">
                                <input type="text" name="start_date" class="form-control ret input--textfield" id="firstd" value="<?php echo e($row->start_date); ?>" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <label class="control-label" for="password">End Admission:</label>
                            <div class="input-group date " id="end_ad">
                                <input type="text" name="end_date" class="form-control ret input--textfield" id="endd" value="<?php echo e($row->end_date); ?>" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <label class="control-label" for="password">Form Amount:</label>
                            <input type="text" class="form-control" name="form_amount" id="f_amt" value="<?php echo e($row->form_amount); ?>" placeholder="Ex.500">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Update</button>                    
                </div>
              <?php echo Form::close(); ?>

                   <?php endforeach; ?>
                </div>
            </div>     
        </div>
    </div>    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>