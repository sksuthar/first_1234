<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .col-sm-8{
            float: none;
        }
    </style>
    <?php 
$home_url = getenv('ADMIN_HOME_URL');
 ?>
    <div class="container">
        <div class="row center-back">
            <?php if(Session::get('success_message')): ?>
                <div class="col-sm-8" style="padding-bottom:15px; margin-left: auto; margin-right: auto; padding-left: 0px; padding-right: 0px; ">
                    <p class="bg-success" style="padding: 15px;"><?php echo Session::get('success_message'); ?></p>
                </div>
            <?php endif; ?>
            <?php if(!empty($class_name)): ?>
                    <div class="col-sm-8" style="padding-bottom:15px; margin-left: auto; margin-right: auto; padding-left: 0px;">
                         <a href="<?php echo e(url("/$home_url")); ?>">Home </a> / <b><a href="<?php echo e(url("/courses-and-classes")); ?>">Courses-and-Classes </a> </b>
                </div>
                <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom: 11em; margin-left: auto;
    margin-right: auto; ">
                    <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="    margin: 15px 0px; padding: 0px 5px 15px 0px;">
                        <span class="heading-main">Course Details</span>
                         <button class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#myModal">Create Course</button>
                    </div>                     
                    <div class="row">
                        <?php foreach(@$class_name as $key=>$row): ?>
                            <a href="<?php echo e(url()->current()."/course?option=1&class_h=".$row->class_hash."&s_i=".$row->school_id); ?>">
                                <div class="col-sm-4 col-md-4 box-6" style="padding: 20px; border: 1px solid #ccc;  margin-top: 1em;">
                                    <?php echo e($key+1); ?>.
                                    <?php echo e($row->class_name); ?>

                                    <?php if($row->status == 0): ?>
                                        <span class="label label-warning pull-right">Incomplete</span>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div> <!-- close container ( center area) -->
    
    <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content" style="    margin-top: 9em;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Create Course</h4>
            </div>
              <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/course_create','enctype' => 'multipart/form-data']); ?>    
                <div class="modal-body">                   
                    <div class="col-sm-12 col-md-12 col-ls-12">
                        <span>Course Name:</span>
                        <input type="text" class="form-control" name="class_name">   
                    </div>
                    <div class="col-sm-12 col-md-12 col-ls-12">
                        <span>Category:</span>
                        <select class="form-control" name="category_name">
                            <option value="">-------select--------</option>
                            <?php foreach($category as $cat): ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <br>
                    </div>                   
                </div>              
              <div class="modal-footer" style="border-top:0px solid #FFF;">
                    <input id="class_name" type="submit" class="btn btn-primary btn-sm" value="Submit">
                    <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>