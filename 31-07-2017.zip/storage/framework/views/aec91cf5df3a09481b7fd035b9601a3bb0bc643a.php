<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Admission schools or colleges</title>
    <link href="<?php echo asset('resources/assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('resources/assets/css/bootstrap-datetimepicker.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('resources/assets/css/style.css'); ?>" rel="stylesheet">
    <script src="<?php echo asset('resources/assets/js/jquery-2.1.1.min.js'); ?>"></script>
    <script src="<?php echo asset('resources/assets/js/bootstrap.min.js'); ?>"></script>
    <script type="text/javascript">
        var BASE_URL = "<?php echo e(url('/')); ?>";
    </script>   
    </head>
    <body>        
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>           
        <?php echo $__env->yieldContent('content'); ?>

        <?php if(Auth::guest()): ?>
             <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
            <?php if(strcmp(Auth::user()->user_role,getenv('STUDENT_CODE'))==1): ?>
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>
    </body>
</html>