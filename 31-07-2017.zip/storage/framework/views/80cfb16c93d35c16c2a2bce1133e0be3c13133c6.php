<?php $__env->startSection('content'); ?>
<style type="text/css">
    .active-home a img{
        border-bottom:2px solid #4ca2f4;
    }
    .active-home a img:hover {
        opacity: 1 !important;
    }
    @media (min-width: 1200px)
    {
        .container-15-15 {
            width: 804px;
            margin-left: auto;
            margin-right: auto;
            margin-top: 9em;
        } 
    }                   
</style>
<div class="container-15-15">   
        <div class="col-sm-12" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
            <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px;">
                <h3>Fill School or College details below  Step - 1</h3>
            </div>             
                <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/school_college_details/two','enctype' => 'multipart/form-data']); ?>

                <?php echo e(csrf_field()); ?>                    
                <div class="form-group<?php echo e($errors->has('school_name') ? ' has-error' : ''); ?>">
                    <div class="col-md-12">
                        <label for="password">School or College Name:</label>
                        <input id="school_name" type="text" class="form-control" name="school_name">
                        <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('school_name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
               <div class="form-group<?php echo e($errors->has('board') ? ' has-error' : ''); ?>">
                    <div class="col-md-12">
                        <label for="board">Board or University:</label>
                        <input id="board" type="text" class="form-control" name="board" value="<?php echo e(@$temp_admin_email[0]['board']); ?>">
                        <?php if($errors->has('board')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('board')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('address_1') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <label for="password">Address 1:</label>
                        <input id="school_id" type="text" class="form-control" name="address_1">
                         <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('address_1')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-6">
                        <label for="password">Address 2:</label>
                        <input id="school_id" type="text" class="form-control" name="address_2">

                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <label for="password">City:</label>
                        <input id="school_id" type="text" class="form-control" name="city">
                         <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('city')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('pin_code') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <label for="password">Pin Code:</label>
                        <input id="school_id" type="text" class="form-control" name="pin_code">
                         <?php if($errors->has('pin_code')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('pin_code')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <label for="password">State:</label>
                        <select class="form-control" name="state_id">
                            <option value="">------------Select State------------</option>
                            <option value="1">Andaman and Nicobar Islands</option>
                            <option value="2">Andhra Pradesh</option>
                            <option value="3">Arunachal Pradesh</option>
                            <option value="4">Assam</option>
                            <option value="5">Bihar</option>
                            <option value="6">Chandigarh</option>
                            <option value="7">Chhattisgarh</option>
                            <option value="8">Dadra and Nagar Haveli</option>
                            <option value="9">Daman and Diu</option>
                            <option value="10">Delhi</option>
                            <option value="11">Goa</option>
                            <option value="12">Gujarat</option>
                            <option value="13">Haryana</option>
                            <option value="14">Himachal Pradesh</option>
                            <option value="15">Jammu and Kashmir</option>
                            <option value="15">Jharkhand</option>
                            <option value="16">Karnataka</option>
                            <option value="17">Kerala</option>
                            <option value="18">Lakshadweep</option>
                            <option value="19">Madhya Pradesh</option>
                            <option value="20">Maharashtra</option>
                            <option value="21">Manipur</option>
                            <option value="22">Meghalaya</option>
                            <option value="23">Mizoram</option>
                            <option value="24">Nagaland</option>
                            <option value="25">Orissa</option>
                            <option value="26">Pondicherry</option>
                            <option value="27">Punjab</option>
                            <option value="28">Rajasthan</option>
                            <option value="29">Sikkim</option>
                            <option value="30">Tamil Nadu</option>
                            <option value="31">Tripura</option>
                            <option value="32">Uttaranchal</option>
                            <option value="33">Uttar Pradesh</option>
                            <option value="34">West Bengal</option>
                        </select>
                         <?php if($errors->has('state')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('state')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('phone_no1') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <label for="password">Phone No 1:</label>
                        <input id="school_id" type="text" class="form-control" name="phone_no1" >
                         <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('phone_no1')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6">
                        <label for="password">Phone No 2:</label>
                        <input id="school_id" type="text" class="form-control" name="phone_no2">

                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6">
                        <label for="password">Phone No 3:</label>
                        <input id="school_id" type="text" class="form-control" name="phone_no3">

                    </div>
                </div>
                <div class="form-group col-md-12">
                    <div class="col-md-6">

                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('school_logo') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <label for="password">School or College logo:</label>
                        <input id="school_id" type="file" class="form-control" name="school_logo">
                         <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('school_logo')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('school_banner') ? ' has-error' : ''); ?>">
                    <div class="col-md-6">
                        <label for="password">School or College banner:</label>
                        <input id="school_id" type="file" class="form-control" name="school_banner">
                         <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('school_banner')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>              
                <div class="form-group">                   
                    <div class="col-md-12" align="center" style="border-top: 1px solid #ccc; padding-top: 3%; margin-top: 3%;">
                        <input id="submit-btn" type="submit" value="Next 1-3" class="btn btn-primary btn-sm" name="submit-btn">
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>      
</div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>