<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .form-group.required .control-label:after {
            content:"*";
            color:red;
        }
        .td_1{
            width: 15%;
        }
        .td_2{
            width: 27%;
        }
        td{
            text-align: center;
        }
    </style>
    
   
    
   
    
    <div class="container">
        <div class="row center-back" >
              
                <div class="col-sm-3" style="border-top: 1px solid #DDD; border-right: 1px solid #DDD; border-left: 1px solid #DDD; margin-right: 15px; ">                    
                      
                </div>
            
          
            <!-- ======================= Center Part ============================ -->
            <div class="col-sm-8" style="border: 1px solid #DDD;  padding-bottom:15px; ">
                <h4>Application Form Details</h4>
                <a class="btn btn-info" href="<?php echo e(URL::previous()); ?>">back</a>
                <table class="table table-striped" >      
                        <thead>
                            <th>Sr.No</th>
                            <th>Name</th>
                            <th>Email Id</th>
                            <th>Mobile</th>
                            <th>Class Name</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php $i =1; ?>
                            <?php foreach($application_details as $row): ?>
                            <tr>
                                 <td><?php echo e($i++); ?></td>
                                 <td><?php echo e($row->f_name); ?></td>
                                 <td><?php echo e($row->userdata['email']); ?></td>
                                 <td><?php echo e($row->mobile); ?></td>
                                 <td><?php echo e($row->classdata['class_name']); ?></td>
                                 <td></td> 
                            </tr>    
                            <?php endforeach; ?>                                                                                    
                        </tbody>
                    </table>                                                                                                                   
            </div>
        </div>
    </div> <!-- close container ( center area) -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>