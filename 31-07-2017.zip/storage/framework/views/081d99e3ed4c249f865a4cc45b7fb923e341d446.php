<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .form-group.required .control-label:after {
            content:"*";
            color:red;
        }
        .td_1{
            width: 15%;
        }
        .td_2{
            width: 27%;
        }
        td{
            text-align: center;
        }
    </style>
    
    <div class="container">
    <div class="row center-back">
        <div class="col-sm-11" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
            <div class="bg-img-fit">
                <div class="row wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                    <div class="col-xs-12">
                        <?php echo Form::open(['files'=>true, 'method'=>'get', 'url'=>'/search','enctype' => 'multipart/form-data']); ?>

                        <div class="col-md-4 col-sm-5 col-xs-11 pad0">
                            <input type="text" class="bot13 pad-in form-control form-text brd-a-2-green" id="email" name="email" placeholder="Search Email">
                        </div>
                        <div class="col-md-4 col-sm-5 col-xs-11 pad0">
                            <input type="text" class="bot13 pad-in form-control form-text brd-a-2-green" id="mobile" name="mobile" placeholder="Search Mobile">
                        </div>
                        <div class="col-md-2 col-sm-2 col-xs-11 pad0">
                            <button type="text" class="bot13 pad-in btn btn-primary form-text brd-a-2-green">Search</button>
                        </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
                </div>
        </div>
    </div>
    </div>
    
   
    
    <div class="container">
        <div class="row center-back" >
                <div class="col-sm-3" style="border-top: 1px solid #DDD; border-right: 1px solid #DDD; border-left: 1px solid #DDD; margin-right: 15px; ">                    
                      <h4>Course Filter</h4>
                      <?php foreach(@$class_details as $key=>$row): ?>
                      <div class="row">
                         <a href="<?php echo e(url("/application_list/search/$row->id")); ?>">  
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <?php echo e($key+1); ?>.
                                <?php echo e($row->class_name); ?>

                            </div>
                          </a>
                      </div>
                      <?php endforeach; ?>    
                </div>

            <!-- ======================= Center Part ============================ -->
            <div class="col-sm-8" style="border: 1px solid #DDD;  padding-bottom:15px; ">
                <h4>Application Form Details</h4>
                <table class="table table-striped" >      
                        <thead>
                            <th>Sr.No</th>
                            <th>Name</th>
                            <th>Email Id</th>
                            <th>Mobile</th>
                            <th>Class Name</th>
                            <th></th>
                        </thead>
                        <tbody>
                            <?php foreach($course_details as $key=>$row): ?>
                            <tr>
                                 <td><?php echo e($key+1); ?></td>
                                 <td><?php echo e($row->f_name); ?></td>
                                 <td><?php echo e($row->userdata['email']); ?></td>
                                 <td><?php echo e($row->mobile); ?></td>
                                 <td><?php echo e($row->classdata['class_name']); ?></td>
                                 <td><a href="<?php echo e(url("/application/$row->id")); ?>" class="btn btn-info btn-sm">Details</a> </td>
                            </tr>
                            <?php endforeach; ?>
                            <tr>
                                <td colspan="6">
                                    <?php if(count($course_details)==0): ?>
                                      <p style="text-align: center;">Not Received application form yet.!</p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>                                                                                                                   
            </div>
        </div>
    </div> <!-- close container ( center area) -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>