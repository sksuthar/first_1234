<?php $__env->startSection('content'); ?>   
<style>
.card.hovercard .cardheader { 
     background: url("<?php echo e(url($schoolData->school_banner)); ?>");
}
</style>

<div class="container application-base-profile">
    <div class="row">
        <div class="col-lg-10 col-sm-10 col-md-10" style="float: none;    margin-left: auto;  margin-right: auto;">
            <div class="card hovercard">
                <div class="cardheader">
                </div>
                <div class="avatar">
                    <img alt="" src="<?php echo e(url($schoolData->school_logo)); ?>">
                </div>
                <div class="info">
                    <div class="title">
                        <p class="head-color" style="margin: 0 0 0px;"><?php echo e($schoolData->school_name); ?></p>
                        [ <?php echo e($schoolData->board); ?> ]
                    </div>
                    <div class="desc"><?php echo e($schoolData->address1); ?> , <?php echo e($schoolData->address2); ?></div>
                        
                </div>             
            </div>

        </div>
        <div class="col-lg-10 col-sm-10 col-md-10" style="float: none;    margin-left: auto;  margin-right: auto; margin-top: 2em;     margin-bottom: 8em;">
            <div style="background: #fff;">
                  

                <div class="row">
                    <div class="col-md-6">
                        <h4 class="profile-head">
                    Details
                  </h4>
                    </div>

                    <div class="col-md-6 text-right">
                    
                    <h4 class="profile-head">
                    <input type="submit" id="school_register" class="btn btn-default" value="Edit">
                    </div>
                </div>
                 <hr style="margin-top: 0px;">
                  <div class="row">
                    <div class="col-md-12 margin-btm-10" style="padding-left: 45px;">
                        <label>School Name :</label> <span><?php echo e($schoolData->school_name); ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 margin-btm-10" style="padding-left: 45px;">
                        <label>Board :</label> <span><?php echo e($schoolData->board); ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 margin-btm-10" style="padding-left: 45px;">
                        <label>Address :</label> <span><?php echo e($schoolData->address1); ?> , <?php echo e($schoolData->address2); ?></span>
                    </div>                     
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 margin-btm-10" style="padding-left: 45px;">
                        <label>City :</label> <span><?php echo e($schoolData->city); ?></span>
                    </div>
                     <div class="col-md-6 col-sm-6 margin-btm-10">
                        <label>State :</label> <span><?php echo e($schoolData->getstate->state); ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 margin-btm-10" style="padding-left: 45px;">
                        <label>Pin Code :</label> <span><?php echo e($schoolData->pincode); ?></span>
                    </div>
                     <div class="col-md-6 col-sm-6 margin-btm-10">
                        <label>Phone 1 :</label> <span><?php echo e($schoolData->phone1); ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 margin-btm-10" style="padding-left: 45px;">
                        <label>Phone 2 :</label> <span><?php echo e($schoolData->phone2); ?></span>
                    </div>
                     <div class="col-md-6 col-sm-6 margin-btm-10">
                        <label>Phone 3 :</label> <span><?php echo e($schoolData->phone3); ?></span>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 margin-btm-10" style="padding-left: 45px;">
                        <label>Email Id :</label> <span><?php echo e($schoolData->school_email); ?></span>
                    </div>
                     <div class="col-md-6 col-sm-6 margin-btm-10">
                        <label>Website :</label> <span><?php echo e($schoolData->website); ?></span>
                    </div>
                </div>
            </div>
        </div>
</div>         
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>