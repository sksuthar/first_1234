<?php $__env->startSection('content'); ?>
    <style>

    </style>
    <div class="container">
        <div class="row center-back">
    <div class="col-sm-3" style="border: 1px solid #DDD; margin-right: 15px; ">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <a href="http://localhost/bizzz/07-07-2017/setting/tab/1">
                    <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                        <span style="color: #20bd99; font-weight: 700;">Classes Details</span>
                    </div>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <a href="http://localhost/bizzz/07-07-2017/setting/tab/2">
                    <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                        <p>Course Details</p>
                    </div>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <a href="http://localhost/bizzz/07-07-2017/setting/tab/3">
                    <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                        <p>Schoool / College Details</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
            <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px;">
                    <h3>Class Details</h3>
                </div>
                <div class="row">
                    <a href="http://localhost/bizzz/07-07-2017/setting/tab/1/class?option=1&amp;class_h=$2y$10$JceI2CwjGyp4gsC0iALSDOSuoX0fT03RAd9XOG1uRy.xu8gvEFLHS&amp;s_i=229">
                        <div class="col-sm-4 col-md-4 box-6" style="padding: 20px; border: 1px solid #ccc;">
                            1.
                            Master Of Bussiness Applicationnn
                        </div>
                    </a>

                </div>
            </div>
        </div>
    </div>




    <div class="container-6" style="padding-top: 9em;">
        <div class="row">
            <?php foreach($class_data as $row1): ?>
                <div class="item box">
                    <?php 
                        $class_hash = $row1->class_hash;
                     ?>
                    <h4><?php echo e($row1->class_name); ?></h4>
                    <?php foreach($row1->courseDetails as $row2): ?>
                        <?php if(@$row2->status == 1): ?>
                            <div  style="border-bottom:1px solid #ccc;     padding: 15px;">
                                <span><?php echo e($row2->course_name); ?></span>
                                <?php if(@$row2->getadmissiondate[0]['admission_status'] == 1): ?>
                                    <span class="label label-success pull-right">Admission Open</span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <div class="col-sm-12 col-md-12" style="padding-top: 15px;">
                        <a href="<?php echo e(url("/admission-status?c_h=".$row1->class_hash)); ?>" class="btn btn-info btn-sm pull-right">Open or Close Admission</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>