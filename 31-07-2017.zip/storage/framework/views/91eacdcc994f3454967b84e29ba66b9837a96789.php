

<?php


echo $post['f_name'];
?>
