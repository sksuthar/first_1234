	<footer>
		<div class="inner-footer">
			<div class="container">
				<?php /*<div class="row">*/ ?>
					<?php /*<div class="col-md-4 f-about">*/ ?>
						<?php /*<a href="index.html"><h1><span>e</span>Nno</h1></a>*/ ?>
						<?php /*<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu libero*/ ?>
						<?php /*vestibulum volutpat libero sollicitudin vitae Curabitur ac aliquam  consectetur adipiscing elit Cras*/ ?>
						<?php /*</p>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<div class="col-md-4 l-posts">*/ ?>
						<?php /*<h3 class="widgetheading">Latest Posts</h3>*/ ?>
						<?php /*<ul>*/ ?>
							<?php /*<li><a href="#">This is awesome post title</a></li>*/ ?>
							<?php /*<li><a href="#">Awesome features are awesome</a></li>*/ ?>
							<?php /*<li><a href="#">Create your own awesome website</a></li>*/ ?>
							<?php /*<li><a href="#">Wow, this is fourth post title</a></li>*/ ?>
						<?php /*</ul>*/ ?>
					<?php /*</div>*/ ?>
					<?php /*<div class="col-md-4 f-contact">*/ ?>
						<?php /*<h3 class="widgetheading">Stay in touch</h3>*/ ?>
						<?php /*<a href="#"><p><i class="fa fa-envelope"></i>sehooa@outlook.com</p></a>*/ ?>
						<?php /*<p><i class="fa fa-phone"></i>  +91 9689326397</p>*/ ?>
						<?php /*<p><i class="fa fa-home"></i> */ ?>
							<?php /*Virar(East) <br>*/ ?>
                                                        <?php /*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Maharashtra</p>*/ ?>
					<?php /*</div>*/ ?>
				<?php /*</div>*/ ?>
			</div>
		</div>
		
		
		<div class="last-div">
			<div class="container">
				<div class="row">
					<div class="copyright">
						&copy; eNno Theme. All Rights Reserved
                        <div class="credits">
                            <!-- 
                                All the links in the footer should remain intact. 
                                You can delete the links only if you purchased the pro version.
                                Licensing information: https://bootstrapmade.com/license/
                                Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=eNno
                            -->
                            <a href="https://bootstrapmade.com/">Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                        </div>
					</div>					
				</div>
			</div>
			<div class="container">
				<div class="row">
					<ul class="social-network">
							<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook fa-1x"></i></a></li>
							<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter fa-1x"></i></a></li>
							<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin fa-1x"></i></a></li>
							<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest fa-1x"></i></a></li>
							<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus fa-1x"></i></a></li>
					</ul>
				</div>
			</div>
			<a href="" class="scrollup"><i class="fa fa-chevron-up"></i></a>
		</div>	
	</footer>
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo asset('resources/assets/js/jquery-2.1.1.min.js'); ?>"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo asset('resources/assets/js/bootstrap.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/moment.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/bootstrap-datetimepicker.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/wow.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/jquery.easing.1.3.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/jquery.isotope.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/jquery.bxslider.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo asset('resources/assets/js/fliplightbox.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/functions.js'); ?>"></script>
	<script type="text/javascript">$('.portfolio').flipLightBox()</script>
	<script type="text/javascript">
        $(document).ready(function () {
            $('[name="user_role"]').val('<?php echo e(old('user_role')); ?>');
        });
	</script>
	<script type="text/javascript">
        $(function()
        {
            var startDate;
            var d = new Date();
            var open = false;
            $('#one_way').datetimepicker({
                allowInputToggle: true ,
                defaultDate: d,
//        autoclose: true,
                format: 'DD-MM-YYYY',
                minDate:d
            });

            //For Start Admisson
            var startDate;
            var d = new Date();
            var open = false;
            $('#start_ad').datetimepicker({
                allowInputToggle: true ,
                defaultDate: d,
//        autoclose: true,
                format: 'DD-MM-YYYY',
                minDate:d
            });

            //For End Admisson
            var startDate;
            var d = new Date();
            var open = false;
            $('#end_ad').datetimepicker({
                allowInputToggle: true ,
                defaultDate: d,
//        autoclose: true,
                format: 'DD-MM-YYYY',
                minDate:d
            });
        });
	</script>
<?php echo $__env->yieldContent('pageFooterSpecificPlugin'); ?>

<?php echo $__env->yieldContent('pageFooterSpecificJS'); ?>