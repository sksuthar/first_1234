<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .row2 {
            -moz-column-width: 400px;
            -webkit-column-width: 400px;
            -moz-column-gap: 15px;
            -webkit-column-gap: 15px;
        }
        .menu-category {
            display: inline-block;
            width: 100%;
            border: 1px solid #ddd;
            margin: 0 0 10px 0;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            border-radius: 2px;
            /* background: #FFF; */
            padding: 15px;
            color: #444;
        }
        .table>tbody>tr>td{
                 border-top: 0px solid #ddd; 
        }
    </style>

    <div class="container">
        <div class="row center-back">
            <div class="col-sm-3" style="border: 1px solid #DDD; margin-right: 15px; ">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <a href="<?php echo e(url("/setting/tab/1")); ?>">
                                <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">                                
                                  <p style="color: #20bd99; font-weight: 700;">Classes Details</p>
                                </div>
                            </a>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/2")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Course Details</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/3")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Schoool / College Details</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
                <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/class/update','enctype' => 'multipart/form-data']); ?>

                  <p style="color:#32CD32; margin: 0 0 10px 0px;"><?php echo Session::get('success_message'); ?></p>
            <input type="hidden" name="c_h"  value="<?php echo e(@$class_data[0]['class_hash']); ?>">
            <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                <h3>
                    <?php echo e(@$class_data[0]['class_name']); ?>

                </h3>
                <table class="table table-hover">
                    <tbody>
                    <tr>
                        <td>Class Name:</td>
                        <td colspan="4">
                            <input id="class_namehgf" type="text" class="form-control" name="class_name"  value="<?php echo e(@$class_data[0]['class_name']); ?>">                            
                        </td>
                    </tr>
                  
                    <tr>
                        <td>Start Date:</td>
                        <td>
                            <div class="input-group date " id="start_ad1">
                                <input type="text" name="start_date" value="<?php echo e(@$class_data[0]->getadmissiondate[0]['start_date']); ?>"  class="form-control ret input--textfield" id="endd" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </td>
                        <td>End Date:</td>
                        <td>
                            <div class="input-group date " id="end_ad1">
                                <input type="text" name="end_date" value="<?php echo e(@$class_data[0]->getadmissiondate[0]['end_date']); ?>" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Form Amount:</td>
                        <td colspan="4">
                            <input id="class_name" type="text" class="form-control" name="form_amount" value="<?php echo e(@$class_data[0]->getadmissiondate[0]['form_amount']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <input id="class_name" type="submit" class="btn btn-success btn-sm pull-right" value="submit">
                        </td>
                    </tr>
                    </tbody>
                </table>
             </div>
               <?php echo Form::close(); ?>

               
             
                   
        </div>
        
        <div class="row">
          <div class="col-sm-3" style="margin-right: 15px; "></div>
               <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; margin-top: 15px; ">
                   <h5>Course Details:</h5>
                   <table class="table table-hover">
                       
                       <div class="input_fields_wrap_class" id="field">
                            <button class="add_field_class btn btn-warning">Add More Fields</button>
                            
                                <input type="text" name="class[]" style="width:80%; display:inline-block;" class="form-control" required="required">
                                <a href="#" class="remove_field btn btn-danger" style="float:right">Remove</a>
                        </div>
                        <?php foreach(@$class_data[0]->courseDetails as $row): ?>
                            <tr>
                                <td></td>
                                <td colspan="3">
                                    <input id="class_name" type="text" class="form-control" name="course_name" _c_d="<?php echo $row->course_hash; ?>" value="<?php echo e($row['course_name']); ?>">
                                </td>
                                <td>
                                    <button class="btn btn-danger btn-sm course_delete" data-toggle="modal" data-c="<?php echo $row->course_hash; ?>" data-target="#deleteCourse">Delete</button>
                                </td>
                            </tr>
                            
                        <?php endforeach; ?> 
                        
                         <tr>
                                <td>
                                    <input id="class_name" type="submit" class="btn btn-success btn-sm pull-right" name="class_name" value="submit">
                                </td>
                            </tr>
                   </table>                   
               </div>
        </div>
        
    </div> <!-- close container ( center area) -->
    <!-- Modal -->
    
    <div id="deleteCourse" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Alert</h4>
        </div>
        <div class="modal-body">
          <p>Are you sure want to delete this product.</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default course_update_btn" id="update_att">Update</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>