<?php $__env->startSection('content'); ?>
<style>
    *,
    *:before,
    *:after {
        box-sizing: border-box;
    }
    .row {
        /* column width */
        -moz-column-width: 25em;
        -webkit-column-width: 25em;

        /* space between columns */
        -moz-column-gap: 1em;
        -webkit-column-gap: 1em;
    }

    .item {
        display: inline-block;
        width: 100%;
    }
    .container{
        width: 970px !important;
    }
</style>

<div class="container" style="padding-top: 9em;">
    <div class="row">
        <?php foreach($class_data as $row1): ?>
            <div class="item box">
                <?php 
                    $class_hash = $row1->class_hash;
                    $rand_str = rand(0,1000);
                         ?>
                <h4><?php echo e($row1->id); ?><?php echo e($row1->class_name); ?></h4>
                <?php foreach($row1->courseDetails as $row2): ?>
                    <?php if(@$row2->status == 1): ?>
                        <div  style="border-bottom:1px solid #ccc;     padding: 15px;">
                            <span><?php echo e($row2->course_name); ?></span>
                            <?php if(@$row2->getadmissiondate[0]['admission_status'] == 1): ?>
                                <span class="label label-success pull-right">Admission Open</span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <div class="col-sm-12 col-md-12" style="padding-top: 15px;">
                    <a href="<?php echo e(url("/admission-status/view?c_h=".$row1->class_hash)); ?>" class="btn btn-info btn-sm pull-right">Open or Close Admission</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>