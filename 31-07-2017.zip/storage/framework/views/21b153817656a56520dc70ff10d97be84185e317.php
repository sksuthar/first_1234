<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .form-group.required .control-label:after {
            content:"*";
            color:red;
        }
        .td_1{
            width: 15%;
        }
        .td_2{
            width: 27%;
        }
    </style>
    <div class="container" style="padding-top:50px;">
        <div class="row">
            <div class="col-sm-3 sol-md-3" style="padding:25px;">
                <img src="" style="border-radius: 15px;"/>
            </div>
            <div class="col-sm-9 sol-md-9" style="padding:25px;">
                <table class="table">
                    <tr>
                        <td>
                            <h4>Personal Details</h4>
                        </td>
                        <td colspan="3">
                          
                        </td>
                    </tr>
                    <?php echo Form::model($row, ['name'=>'edit','id'=>'edit', 'method'=>'PUT', 'url'=> '/profile/update/' . $row->id, 'class'=>'form-horizontal']); ?>

                    <input type="hidden" name="admission_flag" class="form-control" value="<?php echo e($row->admission_flag); ?>">
                    <input type="hidden" name="admission_flag" class="form-control" value="<?php echo e($row->admission_flag); ?>">
                    <tr>
                        <td>
                            First Name:
                        </td>
                        <td>
                            <div class="<?php echo e($errors->has('f_name') ? ' has-error' : ''); ?>">                                                              
                                <input id="f_name" type="text" class="form-control" name="f_name" value="<?php echo e($row->f_name); ?>">
                                <?php if($errors->has('f_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('f_name')); ?></strong>
                                    </span>
                                <?php endif; ?>                               
                            </div>
                        </td>
                         <td>
                            Middle Name:
                        </td>
                        <td>
                            <input type="text" class="form-control" name="m_name" value="<?php echo e($row->m_name); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Last Name:
                        </td>  
                        <td>                           
                            <div class="<?php echo e($errors->has('l_name') ? ' has-error' : ''); ?>">                                                              
                                <input id="f_name" type="text" class="form-control" name="l_name" value="<?php echo e($row->l_name); ?>">
                                <?php if($errors->has('f_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('l_name')); ?></strong>
                                    </span>
                                <?php endif; ?>                               
                            </div>
                        </td>
                         <td>
                           Email:
                        </td>  
                        <td>
                            <input type="text" class="form-control" name="email" value="<?php echo e($row->userdata['email']); ?>" disabled="disabled">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Date Of Birth:
                        </td>  
                        <td>
                             <div class="input-group date " id="one_way">
                                <input type="text" name="dob" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                                <?php if($errors->has('dob')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('dob')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                           </div>
                        </td>
                        <td>
                           Mobile:
                        </td>  
                        <td>
                            <input type="text" class="form-control" name="mobile" value="<?php echo e($row->mobile); ?>">
                        </td>
                    </tr>
                     <tr>
                        <td>
                           Nationality:
                        </td>  
                        <td>
                              <div class="<?php echo e($errors->has('nationality') ? ' has-error' : ''); ?>">                                                        
                                <input id="f_name" type="text" class="form-control" name="nationality" value="<?php echo e($row->nationality); ?>">
                                <?php if($errors->has('nationality')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nationality')); ?></strong>
                                    </span>
                                <?php endif; ?>                               
                            </div>
                        </td>
                        
                    </tr>
                    
                     <tr>
                        <td colspan="7">
                            <h4>Postal Address</h4>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Address 1:
                        </td>  
                        <td>                         
                            <div class="<?php echo e($errors->has('po_add_1') ? ' has-error' : ''); ?>">                                                              
                                <input id="f_name" type="text" class="form-control" name="po_add_1" value="<?php echo e($row->po_add_1); ?>">
                                <?php if($errors->has('po_add_1')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('po_add_1')); ?></strong>
                                    </span>
                                <?php endif; ?>                               
                            </div>
                        </td>
                        <td>
                           Address 2:
                        </td>  
                        <td>                        
                            <div class="<?php echo e($errors->has('po_add_2') ? ' has-error' : ''); ?>">                                                              
                                <input id="f_name" type="text" class="form-control" name="po_add_2" value="<?php echo e($row->po_add_2); ?>">
                                <?php if($errors->has('po_add_2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('po_add_2')); ?></strong>
                                    </span>
                                <?php endif; ?>                               
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            City:
                        </td>  
                        <td>
                            <div class="<?php echo e($errors->has('po_city') ? ' has-error' : ''); ?>">                                                         
                                 <input id="f_name" type="text" class="form-control" name="po_city" value="<?php echo e($row->po_city); ?>">
                                 <?php if($errors->has('po_city')): ?>
                                     <span class="help-block">
                                         <strong><?php echo e($errors->first('po_city')); ?></strong>
                                     </span>
                                 <?php endif; ?>                               
                             </div>
                        </td>
                        <td>
                           State:
                        </td>  
                        <td>
                            <input type="text" class="form-control" name="po_state" value="<?php echo e($row->po_state); ?>">
                        </td>
                    </tr>
                    <tr>
                    <td>
                        Pin Code:
                    </td>  
                    <td colspan="4">                          
                       <div class="<?php echo e($errors->has('po_pin_code') ? ' has-error' : ''); ?>">                                                         
                             <input id="f_name" type="text" class="form-control" name="po_pin_code" value="<?php echo e($row->po_pin_code); ?>">
                             <?php if($errors->has('po_pin_code')): ?>
                                 <span class="help-block">
                                     <strong><?php echo e($errors->first('po_pin_code')); ?></strong>
                                 </span>
                             <?php endif; ?>                               
                         </div>
                    </td>
                       
                    </tr>
                    <tr>
                        <td colspan="6">
                            <input type="submit" value="Update" class="btn btn-success btn-sm">
                              <a class="btn btn-info pull-right" href="<?php echo e(URL::previous()); ?>">back</a>
                        </td>
                    </tr>
                  <?php echo Form::close(); ?>

                </table>
            </div>
        </div>            
    </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>