<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .row2 {
            -moz-column-width: 400px;
            -webkit-column-width: 400px;
            -moz-column-gap: 15px;
            -webkit-column-gap: 15px;
        }
        .menu-category {
            display: inline-block;
            width: 100%;
            border: 1px solid #ddd;
            margin: 0 0 10px 0;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            border-radius: 2px;
            /* background: #FFF; */
            padding: 15px;
            color: #444;
        }
        .table>tbody>tr>td{
                 border-top: 0px solid #ddd; 
        }
        #loaderr{
            position: relative;
            left: 0px;
            top: 0px;
            z-index: 2;
        }
        .box-12 {
            width: 100%;
            padding: 10px 10px 43px 10px;
            height: auto;
            background-color: #fff;
            border: 1px solid #DDD;
            border-radius: 4px;
            /* padding: 28px; */
            margin-bottom: 15px;
            -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
         .col-sm-8{
            float: none;
        }
        .panel{
            margin-top: 20px;
        }
    </style>
<?php 
$home_url = getenv('ADMIN_HOME_URL');
 ?>
<div class="container">
    <div class="row center-back">           
        <?php if(Session::get('success_message')): ?>
        <div class="col-sm-8" style="padding-bottom:15px; margin-left: auto; margin-right: auto; padding-left: 0px; padding-right: 0px; ">           
            <p class="bg-success" style="padding: 15px;"><?php echo Session::get('success_message'); ?></p>          
        </div>
        <?php endif; ?>
        <input type="hidden"  data-c_n="<?php echo e(@$class_data[0]['class_name']); ?>">
        <div class="col-sm-8" style="padding-bottom:15px; margin-left: auto; margin-right: auto; padding-left: 0px;">
            <a href="<?php echo e(url("/$home_url")); ?>">Home </a> / <a href="<?php echo e(url("/courses-and-classes")); ?>">Courses-and-Classes </a> / <b><a href="">Details</a></b>
        </div>
        <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; margin-left: auto; margin-right: auto; ">            
            <div class="panel panel-default">
                <div class="panel-heading"><b>Course Details</b></div>
                <div class="panel-body">
                     <span style="font-size: 16px; font-weight: 600;" id="course_name_edit"><?php echo e(@$class_data[0]['class_name']); ?></span>
                     <button class="btn btn-default btn-sm pull-right" id="course_edit_btn" data-toggle="modal" data-target="#editcourse">Edit</button>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading"><b>Classes Details</b></div>
                <div class="panel-body">
                    <button class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#add_class">Add Class / Division / Semester</button>                  
                </div>
                <ul class="list-group">
                    <?php foreach(@$class_data[0]->courseDetails as $key=>$row): ?>
                        <?php if(@$row['status']==1): ?>
                            <?php 
                            $id = $row->id;
                             ?>                        
                            <li class="list-group-item">
                                <div class="row">
                                    <div class="col-sm-12 col-sm-12 col-lg-12">
                                        <span style="font-size: 18px;">[&nbsp;<?php echo e($row['course_name']); ?>&nbsp;]</span>                                          <button class="btn btn-default btn-sm course_delete pull-right" data-toggle="modal" data-c="<?php echo $row->course_hash; ?>"  data-c_d_i="<?php echo $row->id; ?>" data-target="#deleteCourse" style="margin-left: 10px;">Delete</button>
                                        <button class="btn btn-default btn-sm pull-right class_update" data-_c_i="<?php echo e($row->id); ?>" data-store1="<?php echo e($row['course_name']); ?>" data-store2="<?php echo e($row['fee']); ?>" data-store3="<?php echo e($row['seat']); ?>" >Edit</button>  
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-sm-3 col-sm-3 col-lg-3">
                                        <b>Seat&nbsp;:&nbsp;</b><?php echo e($row['seat']); ?>

                                    </div>
                                     <div class="col-sm-3 col-sm-3 col-lg-3">
                                         <b>Fee&nbsp;:&nbsp;</b><?php echo e($row['fee']); ?>

                                    </div>
                                </div>
                            </li>   
                        <?php endif; ?>
                    <?php endforeach; ?>                        
                </ul>
            </div>                        
         </div>          
    </div>
</div> 
   
<div id="deleteCourse" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Alert</h4>
            </div>
            <div class="modal-body">
              <p>Are you sure want to delete this course?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary course_update_btn btn-sm" id="update_att">Update</button>
              <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div id="deleteCourseSuccess" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Alert</h4>
            </div>
            <div class="modal-body">
                <p  style='color:#32CD32; margin: 0 0 10px 0px;'>Course has been delete successfully</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary course_success">Ok</button>
            </div>
        </div>
    </div>
</div>

<div id="add_class" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Create Class</h4>
            </div>
            <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/course_update','enctype' => 'multipart/form-data']); ?>

            <div class="modal-body">
                <div class="row">
                    <?php 
                        $s_h = bcrypt($class_data[0]['id']);
                        $school_replace_str = str_replace("/","",$s_h);
                     ?>
                    <input type="hidden" name="_d_d_c" value="<?php echo e($class_data[0]['class_hash']); ?>">
                    <input type="hidden" name="_c_d" value="<?php echo e(base64_encode ($class_data[0]['id'])); ?>">
                    <div class="col-sm-12 col-md-12">
                        <label>Enter Class / Division /Semester</label>
                        <input type="text" name="course_new[]" class="form-control">
                    </div>
                    <div class="col-sm-12 col-md-12">
                        <label>Enter Seat No</label>
                        <input type="text" name="seat" class="form-control">
                    </div>
                    <div class="col-sm-12 col-md-12">
                        <label>Enter Fee</label>
                        <input type="text" name="fee" class="form-control">
                    </div>

                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary course_update_btn btn-sm" id="update_att">Update</button>
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<div id="edit_class" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Class</h4>
            </div>
            <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/course_update','enctype' => 'multipart/form-data']); ?>

            <div class="modal-body">
                <div class="row">
                    <?php 
                        $s_h = bcrypt($class_data[0]['id']);
                        $school_replace_str = str_replace("/","",$s_h);
                     ?>
                    <input type="hidden" name="_d_d_c" value="<?php echo e($class_data[0]['class_hash']); ?>">
                    <input type="hidden" name="_c_d" value="<?php echo e(base64_encode ($class_data[0]['id'])); ?>">
                    <input type="hidden" name="_c_i" id="_c_i">
                    <div class="col-sm-12 col-md-12">
                        <label>Enter Class / Division /Semester</label>
                        <input type="text" name="course_u[]" class="form-control" id="course_name">
                    </div>
                    <div class="col-sm-12 col-md-12">
                        <label>Enter Seat No</label>
                        <input type="text" name="seat" class="form-control" id="seat">
                    </div>
                    <div class="col-sm-12 col-md-12">
                        <label>Enter Fee</label>
                        <input type="text" name="fee" class="form-control" id="fee">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary course_update_btn btn-sm" id="update_att">Update</button>
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<div id="editcourse" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
         <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/class/update','enctype' => 'multipart/form-data']); ?>

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Course</h4>
            </div>
            <div class="modal-body">                                                                         
                <span>Course Name:</span>                            
                <input type="text" id="class_val" class="form-control" name="class_name"  value="">
                <input type="hidden" name="c_h"  value="<?php echo e(@$class_data[0]['class_hash']); ?>">                 
            </div>                                                         
            <div class="modal-footer">
                <input id="class_name" type="submit" class="btn btn-primary btn-sm" value="Update">
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            </div>
             <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>