<?php $__env->startSection('content'); ?>    
<div class="container application-base">
    <div class="col-md-8 col-md-offset-2 d_mar-btm">  
        <div class="panel panel-default">
            <div class="panel-heading main-page-head">School Details</div>
            <div class="panel-body">
                <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/school_details/save','enctype' => 'multipart/form-data']); ?>

                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                <div class="row<?php echo e($errors->has('school_name') ? ' has-error' : ''); ?>">
                    <div class="col-md-12 margin-btm">
                        <p>School Name:<span class="star">*</span></p>
                        <input id="school_name" type="text" class="form-control" name="school_name">
                        <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('school_name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row<?php echo e($errors->has('board') ? ' has-error' : ''); ?>">
                    <div class="col-md-12 margin-btm">
                        <p>Board or University Name:<span class="star">*</span></p>
                        <input id="board" type="text" class="form-control" name="board">
                        <?php if($errors->has('board')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('board')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm <?php echo e($errors->has('address1') ? ' has-error' : ''); ?>">
                        <p>Address 1:<span class="star">*</span></p>
                        <input id="address1" type="text" class="form-control" name="address1">
                        <?php if($errors->has('address1')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('address1')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm">
                        <p>Address 2:</p>
                        <input id="address2" type="text" class="form-control" name="address2">
                        <?php if($errors->has('address2')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('address2')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm <?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                        <p>City:<span class="star">*</span></p>
                        <input id="city" type="text" class="form-control" name="city">
                        <?php if($errors->has('city')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('city')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm <?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                        <p>State:<span class="star">*</span></p>
                        <select class="form-control" name="state">
                            <option value="">------Select State------</option>                            
                            <?php foreach($state as $key=>$value): ?>
                                <option value="<?php echo e(++$key); ?>"><?php echo e($value->state); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if($errors->has('state')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('state')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm <?php echo e($errors->has('pincode') ? ' has-error' : ''); ?>">
                        <p>Pin Code:<span class="star">*</span></p>
                        <input id="pincode" type="text" class="form-control" name="pincode">
                        <?php if($errors->has('pincode')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('pincode')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm phone1 <?php echo e($errors->has('phone1') ? ' has-error' : ''); ?>">
                        <p>Phone No 1:<span class="star">*</span></p>
                         <input id="phone1" type="text" class="form-control" name="phone1">
                        <?php if($errors->has('phone1')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('phone1')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm">
                        <p>Phone No 2:</p>
                        <input id="phone2" type="text" class="form-control" name="phone2">                       
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm">
                        <p>Phone No 3:</p>
                         <input id="phone3" type="text" class="form-control" name="phone3">                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm">
                        <p>School Email:</p>
                        <input id="school_email" type="text" class="form-control" name="school_email">                       
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm">
                        <p>Website:</p>
                        <input id="website"  type="text" class="form-control" name="website" placeholder="http://xyz.com">                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm <?php echo e($errors->has('school_logo') ? ' has-error' : ''); ?>">
                        <p>School logo:</p>
                        <input id="school_logo" type="file" class="form-control" name="school_logo">    
                         <?php if($errors->has('school_logo')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('school_logo')); ?></strong>
                            </span>
                        <?php endif; ?>                   
                    </div>
                    <div class="col-md-6 col-sm-6 col-lg-6 margin-btm">
                        <p>School Banner:</p>
                         <input id="school_banner" type="file" class="form-control" name="school_banner">                       
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-lg-12 col-save">
                        <input type="submit" id="school_register" class="new-btn pull-right" value="Save">
                    </div>                        
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div> 
    </div>
</div>
<script src="<?php echo asset('resources/assets/js/jquery.validate.min.js'); ?>"></script>
<script src="<?php echo asset('resources/assets/js/jqueryvalidation.js'); ?>"></script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>