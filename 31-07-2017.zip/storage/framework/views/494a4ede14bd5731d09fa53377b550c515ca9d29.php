<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .row2 {
            -moz-column-width: 400px;
            -webkit-column-width: 400px;
            -moz-column-gap: 15px;
            -webkit-column-gap: 15px;
        }
        .menu-category {
            display: inline-block;
            width: 100%;
            border: 1px solid #ddd;
            margin: 0 0 10px 0;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            border-radius: 2px;
            /* background: #FFF; */
            padding: 15px;
            color: #444;
        }
        .table>tbody>tr>td{
                 border-top: 0px solid #ddd; 
        }
        #loaderr{
            position: relative;
            left: 0px;
            top: 0px;
            z-index: 2;
        }
        .box-12 {
            width: 100%;
            padding: 10px 10px 43px 10px;
            height: auto;
            background-color: #fff;
            border: 1px solid #DDD;
            border-radius: 4px;
            /* padding: 28px; */
            margin-bottom: 15px;
            -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
    </style>

    <div class="container">

        <div class="row center-back">
            <div class="col-sm-3" style="border: 1px solid #DDD; margin-right: 15px; ">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <a href="<?php echo e(url("/setting/tab/1")); ?>">
                                <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">                                
                                  <p style="color: #20bd99; font-weight: 700;">Classes Details</p>
                                </div>
                            </a>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/2")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Course Details</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/3")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Schoool / College Details</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <h3>
                <?php echo e(@$class_data[0]['class_name']); ?>

            </h3>
            <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/class/update','enctype' => 'multipart/form-data']); ?>

              <p style="color:#32CD32; margin: 0 0 10px 0px;"><?php echo Session::get('success_message'); ?></p>
            <input type="hidden" name="c_h"  value="<?php echo e(@$class_data[0]['class_hash']); ?>">
            <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
             <div class="box-12" style="margin-top: 15px;">
                <span>Class Name:</span>
                <input id="class_namehgf" type="text" class="form-control" name="class_name"  value="<?php echo e(@$class_data[0]['class_name']); ?>"><br>
                <input id="class_name" type="submit" class="btn btn-success btn-sm pull-right" value="Update">
             </div>

             </div>
               <?php echo Form::close(); ?>

        </div>
        
        <div class="row">
            <div class="col-sm-3" style="margin-right: 15px; "></div>
            <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; margin-top: 15px; ">
                <div id="success_msg">
                </div>
                   <p style="color:#32CD32; margin: 0 0 10px 0px;"><?php echo Session::get('success_course'); ?></p>
                <h4>Class Details:</h4>
                <button class="btn btn-warning btn-sm pull-right" data-toggle="modal" data-target="#add_class" style="margin-top: -25px;">Add Class / Division / Semester</button><br>
                <?php foreach(@$class_data[0]->courseDetails as $key=>$row): ?>
                    <?php if(@$row['status']==1): ?>
                        <?php 
                        $id = $row->id;
                         ?>
                        <div class="box-12">
                            <span style="font-size: 18px;"><?php echo e(@$class_data[0]['class_name']); ?> - [&nbsp;<?php echo e($row['course_name']); ?>&nbsp;]</span>

                            <a href="#" class="pull-right class_update" data-_c_i="<?php echo e($row->id); ?>" data-store1="<?php echo e($row['course_name']); ?>" data-store2="<?php echo e($row['fee']); ?>" data-store3=<?php echo e($row['seat']); ?> >
                                <span class="glyphicon glyphicon-pencil"></span>
                            </a><br>

                            <div class="pull-left">Seat:<?php echo e($row['seat']); ?></div>
                            <div class="pull-right">Fee:<?php echo e($row['fee']); ?></div>
                            <br>
                            <a class="btn btn-danger btn-sm course_delete pull-right" data-toggle="modal" data-c="<?php echo $row->course_hash; ?>"  data-c_d_i="<?php echo $row->id; ?>" data-target="#deleteCourse">Delete</a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
             </div>
        </div>
    </div> <!-- close container ( center area) -->
    <!-- Modal -->
   
        <div id="deleteCourse" class="modal fade" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Alert</h4>
            </div>
            <div class="modal-body">
              <p>Are you sure want to delete this course?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default course_update_btn" id="update_att">Update</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

    <div id="deleteCourseSuccess" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Alert</h4>
                </div>
                <div class="modal-body">
                    <p  style='color:#32CD32; margin: 0 0 10px 0px;'>Course has been delete successfully</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary course_success" id="update_att">Ok</button>
                </div>
            </div>
        </div>
    </div>

    <div id="add_class" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Class</h4>
                </div>
                <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/course_update','enctype' => 'multipart/form-data']); ?>

                <div class="modal-body">
                    <div class="row">
                        <?php 
                            $s_h = bcrypt($class_data[0]['id']);
                            $school_replace_str = str_replace("/","",$s_h);
                         ?>
                        <input type="hidden" name="_d_d_c" value="<?php echo e($class_data[0]['class_hash']); ?>">
                        <input type="hidden" name="_c_d" value="<?php echo e(base64_encode ($class_data[0]['id'])); ?>">
                        <div class="col-sm-12 col-md-12">
                            <label>Enter Class / Division /Semester</label>
                            <input type="text" name="course_new[]" class="form-control">
                        </div>
                        <div class="col-sm-12 col-md-12">
                            <label>Enter Seat No</label>
                            <input type="text" name="seat" class="form-control">
                        </div>
                        <div class="col-sm-12 col-md-12">
                            <label>Enter Fee</label>
                            <input type="text" name="fee" class="form-control">
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success course_update_btn" id="update_att">Update</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

    <div id="edit_class" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Class</h4>
                </div>
                <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/course_update','enctype' => 'multipart/form-data']); ?>

                <div class="modal-body">
                    <div class="row">
                        <?php 
                            $s_h = bcrypt($class_data[0]['id']);
                            $school_replace_str = str_replace("/","",$s_h);
                         ?>
                        <input type="hidden" name="_d_d_c" value="<?php echo e($class_data[0]['class_hash']); ?>">
                        <input type="hidden" name="_c_d" value="<?php echo e(base64_encode ($class_data[0]['id'])); ?>">
                        <input type="hidden" name="_c_i" id="_c_i">
                        <div class="col-sm-12 col-md-12">
                            <label>Enter Class / Division /Semester</label>
                            <input type="text" name="course_u[]" class="form-control" id="course_name">
                        </div>
                        <div class="col-sm-12 col-md-12">
                            <label>Enter Seat No</label>
                            <input type="text" name="seat" class="form-control" id="seat">
                        </div>
                        <div class="col-sm-12 col-md-12">
                            <label>Enter Fee</label>
                            <input type="text" name="fee" class="form-control" id="fee">
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success course_update_btn" id="update_att">Update</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>