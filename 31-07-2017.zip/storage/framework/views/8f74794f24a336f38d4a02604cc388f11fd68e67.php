<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .form-group.required .control-label:after {
            content:"*";
            color:red;
        }
        .td_1{
            width: 15%;
        }
        .td_2{
            width: 27%;
        }
    </style>
    <div class="container">
        <div class="row center-back">
        <div class="row">
            <div class="col-sm-3 sol-md-3" style="margin-top: 64px; padding:25px; border: 1px solid #DDD; margin-right: 5px;">
                <div class="row">
                    <a href="http://localhost/wi/27-06-2017/application_list/search/436">  
                       <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                           1. Master Of Computer Application
                       </div>
                    </a>
                </div>
                <div class="row">
                    <a href="http://localhost/wi/27-06-2017/application_list/search/436">  
                       <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                           2. Master Of Computer Application
                       </div>
                    </a>
                </div>   
                <div class="row">
                    <a href="http://localhost/wi/27-06-2017/application_list/search/436">  
                       <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                           3. Master Of Computer Application
                       </div>
                    </a>
                </div>   
            </div>
            <div class="col-sm-8 sol-md-8" style="padding:25px;">
                Admision Status          
                  <p style="color:#32CD32; margin: 0 0 10px 0px;"><?php echo Session::get('success_msg'); ?></p>
                      <h3> <?php echo e($class_data['class_name']); ?></h3> 
                    <div style="border: 1px solid #DDD;  padding-bottom:30px; ">
                        <?php if(!empty($class_data)): ?>
                            <?php foreach($class_data->courseDetails as $row): ?>
                                <div style="border-bottom: 1px solid #ccc;    padding: 25px 15px 44px 21px;">                                          
                                    <span style="    color: #20bd99; font-weight: 700;"> <?php echo e(@$row['course_name']); ?></span><br> 
                                    <span class="pull-left">Status :  
                                        <?php if($row['status'] == 1): ?>
                                            <span class="label label-success">Open</span>
                                        <?php else: ?>
                                            <span class="label label-danger">Close</span>
                                        <?php endif; ?>
                                    </span><br> 
                                     <?php if($row['status'] == 1): ?>
                                    <button type="button" class="btn btn-danger btn-sm pull-right" data-toggle="modal" data-target="#myModal">Close</button>
                                  
                                    <?php else: ?>
                                    <button type="button" class="btn btn-success btn-sm pull-right" data-toggle="modal" data-target="#myModal">Open</button>
                                    <?php endif; ?>

                                    <a href="<?php echo e(url("active-admissions/$class_hash/$row[id]/edit")); ?>" class="btn btn-sm btn-warning pull-right">Edit</a>
                                </div>    
                            <?php endforeach; ?>
                      <?php endif; ?>
                    </div>
            </div>     
        </div>
    </div>    
</div>
    
    <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>