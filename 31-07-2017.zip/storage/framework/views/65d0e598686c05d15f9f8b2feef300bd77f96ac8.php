<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
    </style>
    <div class="container">
        <div class="row center-back">
            <!-- ======================= Center Part ============================ -->
            <div class="col-sm-9" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                
                
                  <h3><?php echo e(@$temp_admin_email[0]['school_name']); ?>  College details</h3>
                <table class="table table-hover">
   
    <tbody>
      <tr>
        <td>School or College Name:</td>
        <td><?php echo e(@$temp_admin_email[0]['school_name']); ?></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
          <td><label>Address 1:</label></td>
        <td><?php echo e(@$temp_admin_email[0]['address_1']); ?></td>
        <td>Address 1:</td>
        <td><?php echo e(@$temp_admin_email[0]['address_1']); ?></td>
      </tr>
      <tr>
        <td>City :</td>
        <td><?php echo e(@$temp_admin_email[0]['city']); ?></td>
        <td>Pin Code :</td>
        <td><?php echo e(@$temp_admin_email[0]['pin_code']); ?></td>
      </tr>
       <tr>
        <td>City :</td>
        <td><?php echo e(@$temp_admin_email[0]['city']); ?></td>
        <td>Pin Code :</td>
        <td><?php echo e(@$temp_admin_email[0]['pin_code']); ?></td>
      </tr>
       <tr>
        <td>State :</td>
        <td> <?php echo e(@$temp_admin_email[0]->getstate['state_name']); ?></td>
        <td>Phone No 1 :</td>
        <td><?php echo e(@$temp_admin_email[0]['phone_no1']); ?></td>
      </tr>
      <tr>
        <td>Phone No 2 :</td>
        <td><?php echo e(@$temp_admin_email[0]['phone_no2']); ?></td>
        <td>Phone No 3 :</td>
        <td><?php echo e(@$temp_admin_email[0]['phone_no3']); ?></td>
      </tr>
   
    </tbody>
  </table>
                
                    <div class="form-group">
                    <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px; margin-top: 20px;">
                        <h4>Classes details</h4>
                    </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-8">
                          <input type="hidden" name="count" value="1" />
                            <div class="control-group" id="fields">
                                <label class="control-label" for="field1">Class Name:</label>                                                                
                                <div class="controls" id="profs">
                                    <form class="input-append">
                                        <?php if(@$classes_details): ?>
                                            <?php $i = 1;?>
                                            <?php foreach(@$classes_details as $row): ?>
                                               <div class="input_fields_wrap" id="field">                                           
                                                    <div style="margin: 7px 0px;">
                                                        <p><?php echo e($i++); ?> . <?php echo e($row->class_name); ?></p>
                                                </div>
                                               </div>
                                            <?php endforeach; ?>                                                
                                        <?php endif; ?>
                                 
                                    </form>
                                    <br>
                                </div>                                                                
                            </div>
                        </div>
                        
                    </div>                                
            </div>
            <!-- ======================= Right Part ============================ -->

            <div class="col-sm-3 span3">
                <div>
                    <header>
                        <div class="box sb-right" style="background-color:#2cc16b; color:#fff; border:none;">
                            <span><i class="calendar icon"></i> Today</span>
                            <div style="margin-top:5px;">
                                <span style="font-size:18px;"><?php echo date("l, j F"); ?></span>
                            </div>
                        </div>

                    </header>
                    <div id="affi">
                        <div class="box">
                            <span style="color:#bbb;">My College</span>
                            <div style="margin-top:10px;" align="right">
                                <img style="margin-left:-10px; margin-bottom:10px;" src="assets/images/college.jpg" width="109%" height="auto">
                                <button class="btn btn-default btn-xs">Manage page</button>
                            </div>
                        </div>
                        <div class="box">
                            <p class="terms">sehooa &copy 2015</p>
                            <a class="a-tag terms" href="#">About</a>&nbsp
                            <a class="a-tag terms" href="#">Help</a>&nbsp
                            <a class="a-tag terms" href="#">Privace</a>&nbsp
                            <a class="a-tag terms" href="#">Terms</a>&nbsp
                            <a class="a-tag terms" href="#">Cookies</a>
                        </div>
                    </div>
                </div><!-- Fixed Div -->
            </div>
            <!-- ==== Close Right ====== -->
        </div>
    </div> <!-- close container ( center area) -->
    <script type="text/javascript">
        $('#affi').affix({
            offset: {
                top: $('header').height()
            }
        });


    </script>
    <style type="text/css">
        header {
            height:auto;
        }

        #affi.affix {
            position: fixed;
            top: 100px;
            width:277px;
        }
    </style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>