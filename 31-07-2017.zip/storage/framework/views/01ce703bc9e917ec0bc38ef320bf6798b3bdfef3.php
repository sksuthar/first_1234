<?php $__env->startSection('content'); ?>
<style type="text/css">
    .active-home a img{
        border-bottom:2px solid #4ca2f4;
    }
    .active-home a img:hover {
        opacity: 1 !important;
    }
     @media (min-width: 1200px)
    {
        .container-15-15 {
            width: 30em;
            margin-left: auto;
            margin-right: auto;
            margin-top: 9em;
        } 
    }
</style>
<div class="container-15-15">       
    <div class="col-sm-12" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
        <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px;">
            <h3>Add Class</h3>             
        </div>
        <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/school_college_details/threeStepStore','enctype' => 'multipart/form-data']); ?>                       
        <div class="input_fields_wrap2 form-group">    
           <div class="form-group">                                           
               <div class="col-md-12">
                   <label>Course Name:</label>
                   <select class="form-control" name="class">
                       <option>-----------select-----------</option>
                       <?php foreach($class_data as $data): ?>
                           <option value="<?php echo e($data->id); ?>"><?php echo e($data->class_name); ?></option>
                       <?php endforeach; ?>
                   </select>
               </div>
           </div>                                                                         
           <div class="form-group">                                           
               <div class="col-md-12">
                   <div style="margin-top: 15px; margin-bottom: 15px;">
                        <label>Enter Class Name:</label>
                        <button class="add_field_button1 btn btn-warning btn-sm pull-right">Add Classes Fields</button>
                        <div class="input_fields_wrap1" >
                            <input type="text" name="course[]" class="form-control" required="required">
                            <div class="form-group">                                           
                                <div class="col-md-6">
                                    <label>Enter Seat No:</label>
                                    <input type="text" name="seat[]" class="form-control" required="required">                     
                                </div>
                                <div class="col-md-6">
                                   <label>Enter Fee:</label>
                                   <input type="text" name="fee[]" class="form-control" required="required">                      
                               </div>
                            </div>    
                        </div>                                              
                   </div>                              
               </div>
           </div>                 
                 
        </div>
        <div class="col-md-12" align="center" style="border-top: 1px solid #ccc; padding-top: 3%;     margin-top: 4%;">              
            <input id="submit-btn" type="submit" value="Next 3-3" class="btn btn-primary btn-sm">
        </div>
       <?php echo Form::close(); ?>

    </div>             
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>