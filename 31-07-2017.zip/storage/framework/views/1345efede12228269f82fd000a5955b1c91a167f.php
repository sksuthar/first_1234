<style>
	.dropdown ul.dropdown-menu {
		border-radius:4px;
		box-shadow:none;
		margin-top:20px;
		margin-left: -210px;
		width:300px;
	}
	.dropdown ul.dropdown-menu:before {
		content: "";
		border-bottom: 10px solid #fff;
		border-right: 10px solid transparent;
		border-left: 10px solid transparent;
		position: absolute;
		top: -10px;
		right: 16px;
		z-index: 10;
	}
	.dropdown ul.dropdown-menu:after {
		content: "";
		border-bottom: 12px solid #ccc;
		border-right: 12px solid transparent;
		border-left: 12px solid transparent;
		position: absolute;
		top: -12px;
		right: 14px;
		z-index: 9;
	}
	.navbar-default .navbar-nav>li>a{color: #fff !important;}
	.navbar-nav>li>a:hover{color: #000 !important;}
</style>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo e(url('/home')); ?>"><span>Onlineadmission</span></a>
			</div>
			<div class="navbar-collapse collapse">
				<div class="menu">
					<ul class="nav nav-tabs" role="tablist">
						<?php if(Auth::guest()): ?>
							<li role="presentation"><a href="<?php echo e(url('/login')); ?>">Login/Register</a></li>
						<?php else: ?>
							<ul class="nav navbar-nav">
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e(ucfirst(Auth::user()->name)); ?>&nbsp;&nbsp;<span class="glyphicon glyphicon-user pull-right"></span></a>
									<ul class="dropdown-menu">
										<li><a href="#">Account Settings <span class="glyphicon glyphicon-cog pull-right"></span></a></li>
										<li class="divider"></li>
										<?php if(strcmp(Auth::user()->user_role,getenv('ADMIN_CODE'))==0): ?>
											<li><a href="<?php echo e(url('/school_college_details/one')); ?>">School and College details<span class="glyphicon glyphicon-cog pull-right"></span></a></li>
											<li class="divider"></li>
										<?php endif; ?>
										<?php if(strcmp(Auth::user()->user_role,getenv('ADMIN_CODE'))==1): ?>
											<li><a href="<?php echo e(url('/application_form')); ?>">Admission Form<span class="glyphicon glyphicon-cog pull-right"></span></a></li>
											<li class="divider"></li>
										<?php endif; ?>
										<li><a href="#">Messages <span class="badge pull-right"> 42 </span></a></li>
										<li class="divider"></li>
										<li><a href="<?php echo e(url('/logout')); ?>">Sign Out <span class="glyphicon glyphicon-log-out pull-right"></span></a></li>
									</ul>
								</li>
							</ul>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</nav>