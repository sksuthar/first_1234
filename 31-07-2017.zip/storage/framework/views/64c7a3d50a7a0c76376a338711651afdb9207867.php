<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .row2 {
            -moz-column-width: 400px;
            -webkit-column-width: 400px;
            -moz-column-gap: 15px;
            -webkit-column-gap: 15px;
        }
        .menu-category {
            display: inline-block;
            width: 100%;
            border: 1px solid #ddd;
            margin: 0 0 10px 0;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            border-radius: 2px;
            /* background: #FFF; */
            padding: 15px;
            color: #444;
        }
    </style>
    <div class="container">
        <div class="row center-back">
            <div class="col-sm-3" style="border: 1px solid #DDD; margin-right: 15px; ">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <a href="<?php echo e(url("/setting/tab/1")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                              <p>Classes Details</p>
                            </div>
                        </a>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/2")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Course Details</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/3")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Schoool / College Details</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                <h3>
                    <?php echo e($class_data['class_name']); ?>

                </h3>
                <table class="table table-hover">
                    <tbody>
                    <tr>
                        <td>Class Name:</td>
                        <td colspan="4"><input id="class_name" type="text" class="form-control" name="class_name"  value="<?php echo e($class_data['class_name']); ?>"></td>
                    </tr>
                    <?php foreach(@$class_data->courseDetails as $row): ?>
                    <tr>
                        <td></td>
                        <td colspan="3"><input id="class_name" type="text" class="form-control" name="class_name" value="<?php echo e($row['course_name']); ?>"></td>
                        <td><button class="btn btn-danger btn-sm" ng-click='delete("$class_data[id]")'>Delete</button></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td>Start Date:</td>
                        <td>
                            <div class="input-group date " id="start_ad1">
                                <input type="text" name="dob" value="<?php echo e($class_data->getadmissiondate[0]['start_date']); ?>"  class="form-control ret input--textfield" id="endd" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </td>
                        <td>End Date:</td>
                        <td>
                            <div class="input-group date " id="end_ad1">
                                <input type="text" name="dob" value="<?php echo e($class_data->getadmissiondate[0]['end_date']); ?>" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Form Amount:</td>
                        <td colspan="4">
                            <input id="class_name" type="text" class="form-control" name="class_name" value="<?php echo e($class_data->getadmissiondate[0]['form_amount']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <input id="class_name" type="submit" class="btn btn-success btn-sm pull-right" name="class_name" value="submit">
                        </td>
                    </tr>
                    </tbody>
                </table>


            </div>
            <!-- ======================= Right Part ============================ -->


            <!-- ==== Close Right ====== -->
        </div>
    </div> <!-- close container ( center area) -->
    <!-- Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>