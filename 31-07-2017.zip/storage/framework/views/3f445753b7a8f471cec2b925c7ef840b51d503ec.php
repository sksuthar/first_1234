<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Admission schools or colleges</title>

    <!-- Bootstrap -->
    <link href="<?php echo asset('resources/assets/css/bootstrap.min.css'); ?>" rel="stylesheet">    
    <link rel="stylesheet" href="<?php echo asset('resources/assets/css/animate.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('resources/assets/css/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('resources/assets/css/jquery.bxslider.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('resources/assets/css/normalize.css'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo asset('resources/assets/css/demo.css'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo asset('resources/assets/css/set1.css'); ?>" />
    <link href="<?php echo asset('resources/assets/css/overwrite.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('resources/assets/css/style.css'); ?>" rel="stylesheet">
    <!-- =======================================================
        Theme Name: eNno
        Theme URL: https://bootstrapmade.com/enno-free-simple-bootstrap-template/
        Author: BootstrapMade
        Author URL: https://bootstrapmade.com
    ======================================================= -->
  </head>
  <body>            
            <?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>           
            <?php echo $__env->yieldContent('content'); ?>  
            <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>      
    </body>
</html>