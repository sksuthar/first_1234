<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .form-group.required .control-label:after {
            content:"*";
            color:red;
        }
        .td_1{
            width: 15%;
        }
        .td_2{
            width: 27%;
        }
    </style>
    <div class="container" style="padding-top:50px;">
        <div class="row">
            <div class="col-sm-3 sol-md-3" style="padding:25px;">
            
            </div>
            <div class="col-sm-9 sol-md-9" style="padding:25px;">
                <h4>Admision Details</h4>                                 
                  <div style="border: 1px solid #DDD;  padding-bottom:15px; ">
                      <?php if(!empty(@$admission_data)): ?>
                    <?php foreach(@$admission_data as $row): ?>
                        <div style="border-bottom: 1px solid #ccc; padding: 15px;">
                            <span style="    color: #20bd99;
    font-weight: 700;"> <?php echo e(@$row->classdata['class_name']); ?></span><span class="pull-right">Admisson Date : <?php echo e(date('d-m-Y', strtotime(@$row->created_at))); ?></span><br>    
                        <?php echo e(@$row->coursedata['course_name']); ?>    <br>  
                        School / College : <?php echo e(@$row->schooldata['school_name']); ?>  
                        </div>
                    <?php endforeach; ?>
                    <?php else: ?>
                     <div style="border-bottom: 1px solid #ccc; padding: 75px;">                       
                         <div style="color: #20bd99; font-weight: 700; text-align: center;"> Not yet take admission</div>
                        </div>
                    <div style="text-align: center; padding-top: 15px;"><a href="<?php echo e(url('/')); ?>">Take Admission</a></div>
                    <?php endif; ?>
                  </div>
            </div>
        </div>            
    </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>