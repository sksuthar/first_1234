<?php $__env->startSection('content'); ?>
    <style>

    </style>
    <div class="container">
        <div class="row center-back">
            <div class="col-sm-3" style="border: 1px solid #DDD; margin-right: 15px; ">              
                 <?php foreach($class_nav as $nav): ?>
                
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <a href=" <?php echo e(url()->current()."?c_h=".$nav->class_hash); ?>">
                                <?php if($class_data[0]->id == $nav->id): ?>
                                    <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                        <span style="color: #20bd99; font-weight: 700;"><?php echo e($nav->class_name); ?></span>
                                    </div>
                                <?php else: ?>
                                    <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                        <span style="font-weight: 700;"><?php echo e($nav->class_name); ?></span>
                                    </div>
                                <?php endif; ?>
                            </a>
                        </div>
                    </div>
                 <?php endforeach; ?>
            </div>
            <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px;">
                    <h4>Admission Status</h4>
                    
                </div>
                 <p style="color:#32CD32; margin: 0 0 10px 0px;"><?php echo Session::get('success_status'); ?></p>
                <div class="row">
                    <?php foreach($class_data as $row1): ?>
                    <h4 style="    margin-left: 1.5em;"><?php echo e($row1->class_name); ?></h4>
                        <?php foreach($row1->courseDetails as $row2): ?>
                            <?php if(@$row2->status == 1): ?>                            
                                <div class="col-sm-4 col-md-4 box-6" style="padding: 30px; border: 1px solid #ccc;">
                                     <div class="col-sm-12 col-md-12">
                                        <span><?php echo e($row2->id); ?><?php echo e($row2->course_name); ?></span>
                                        <?php  $seat = $row2->seat;  ?>
                                         <?php if(@$row2->getadmissiondate[0]['admission_status'] == 1): ?>
                                            <span class="label label-success pull-right">Admission Open</span>
                                        <?php endif; ?>
                                    </div>         
                                    <div class="col-sm-12 col-md-12">
                                        <?php if(@$row2->getadmissiondate[0]['admission_status'] == 0): ?>
                                            <button class="btn btn-warning btn-sm pull-right new_admission" data-toggle="modal" data-target="#add_admission_status" data-co_i="<?php echo e(base64_encode ($row2->id)); ?>" data-_c_i_d="<?php echo e(base64_encode ($row1->id)); ?>" data-_c_i ="<?php echo e($class_hash); ?>">Open Admission</button>
                                        <?php else: ?>
                                            <button class="btn btn-info btn-sm admission_status_open pull-right" data-toggle="modal" data-target="#update_admission_status" data-co_i="<?php echo e(base64_encode ($row2->id)); ?>" data-_c_i_d="<?php echo e(base64_encode ($row1->id)); ?>" data-_c_i ="<?php echo e($class_hash); ?>">Edit</button>
                                        <?php endif; ?>
                                    </div>                                                                                                            
                                </div>                            
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
 <div id="update_admission_status" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="" id="form_update_ad_status" method="post">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Active and De-active </h4>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-12 alert alert-info">
                Current Admission Date
            </div>
             <div id="get_status_ad">

            </div>
            <div class="col-sm-12 col-md-12 col-lg-12 alert alert-warning" style="    margin-top: 28px;">
                New Admission Date
            </div>
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <label class="control-label" for="password">Open Admission Date:</label>
                    <div class="input-group date start_ad" id="start_ad">
                        <input type="text" name="start_date" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <label class="control-label" for="password">End Admission Date:</label>
                    <div class="input-group date end_ad" id="end_ad">
                        <input type="text" name="end_date" class="form-control ret input--textfield" id="endd" autocomplete="off">
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>             
                <div class="modal-footer">
                    <div class='col-sm-12 col-md-12 col-lg-12' style='padding: 17px;'>
                        <input type='submit' value='Update' class='btn btn-success btn-sm pull-right' >
                    </div>               
                </div>
            </form>              
        </div>
    </div>
</div>
    
 <div id="add_admission_status" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(url("/admission-status/update")); ?>" id="form_update_ad_status" method="post">
                <input type="hidden" id="status_1" name="co_i">
                <input type="hidden" id="status_2" name="_c_i_d">
                <input type="hidden" id="status_3" name="_c_i">
                <input type="hidden" value="_io" name="n_a">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">New admission activation</h4>
                </div>                               
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <label class="control-label" for="password">Open Admission Date:</label>
                    <div class="input-group date start_add" id="start_ad">
                        <input type="text" name="start_date" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <label class="control-label" for="password">End Admission Date:</label>
                    <div class="input-group date end_add" id="end_ad">
                        <input type="text" name="end_date" class="form-control ret input--textfield" id="endd" autocomplete="off">
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>      
                <div class="col-sm-12 col-md-12" style="margin: 17px 0px;">
                    <label> Merit List Type? </label>
                </div>
                <div class="col-sm-12 col-md-12">
                    <input type="radio" id="merit_type1" name="merit_type" value="<?php echo e(base64_encode(1)); ?>"  required="required" />
                    <label for="merit_type1">Percentage or grade or CGPA wise</label>
                </div>
                <div class="col-sm-12 col-md-12">
                    <input type="radio" id="merit_type2" name="merit_type" value="<?php echo e(base64_encode(2)); ?>" />
                    <label for="merit_type2">First come first serve wise</label>
                </div>  
                <div class="col-sm-12 col-md-12">
                    <input type="radio" id="cbxShowHide" name="merit_type" value="<?php echo e(base64_encode(3)); ?>" />
                    <label for="cbxShowHide">Category wise</label>
                    <div id="block"  style="display: none">
                        Total Seat:<label id="total_seat"><?php echo e($seat); ?></label>
                          <?php  $i=1;  ?>
                          <?php foreach($caste_category as $row): ?>
                             <div class="col-sm-12 col-md-12">
                                 <span><?php echo e($row->caste_category); ?></span>
                                 <input type="text" name="caste_category[<?php echo e(base64_encode($row->id)); ?>]" id="cc_<?php echo e($i++); ?>" class="form-control caste_category">
                             </div>
                          <?php endforeach; ?>                       
                    </div>
                </div>                  
                <div class="modal-footer">
                    <div class='col-sm-12 col-md-12 col-lg-12' style='padding: 17px;'>
                        <input type='submit' value='Update' class='btn btn-success btn-sm'>
                        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
                    </div>               
                </div>
            </form> 
        </div>
    </div>
</div>  


<div id="seat_d" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Alert</h4>
      </div>
      <div class="modal-body">
         <label>Not enter more than <?php echo e($seat); ?> seats</label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default clear" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript">
    $(document).ready(function(){
       $('#cbxShowHide').click(function(){
             if(this.checked){
                $('#block').show();
             }else{
                 $('#block').hide();
             }
        });
       $('#merit_type1 , #merit_type2').click(function(){
             if(this.checked){
                $('#block').hide();
             }
        });

        var select_seat = ['','',''];
            
        $(".caste_category").on('keyup',function()
        {        
            var len=0;
            var myTotal = 0;  // Variable to hold your total
            var total_seat =  $("#total_seat").text();

           

            select_seat.splice($(".caste_category").index($(this)), 1, Number(this.value));
                
            for(var i = 0, len = select_seat.length; i < len; i++) {
               
                myTotal += select_seat[i];  // Iterate over your first array and then grab the second element add the values up
            }
           
            if(Number(total_seat) < Number(myTotal))
            {                  
                $("#seat_d").modal("show");
            }            
        });
        
        $(".clear").click(function(){
            $("input[type='text']").val(""); 
        });
    });
</script>>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>