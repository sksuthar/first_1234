	<footer>
		<div class="inner-footer">
			<div class="container">				
			</div>
		</div>
		
		
		<div class="last-div">
			<div class="container">
				<div class="row">
					<div class="copyright">
						&copy; eNno Theme. All Rights Reserved
						<div class="credits">
							<a href="https://bootstrapmade.com/">Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
						</div>
					</div>					
				</div>
			</div>
			<div class="container">
				<div class="row">
					<ul class="social-network">
					<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook fa-1x"></i></a></li>
					<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter fa-1x"></i></a></li>
					<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin fa-1x"></i></a></li>
					<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest fa-1x"></i></a></li>
					<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus fa-1x"></i></a></li>
					</ul>
				</div>
			</div>
			<a href="" class="scrollup"><i class="fa fa-chevron-up"></i></a>
		</div>	
	</footer>
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
       
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="<?php echo asset('resources/assets/js/bootstrap.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/moment.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/bootstrap-datetimepicker.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/wow.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/jquery.easing.1.3.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/jquery.isotope.min.js'); ?>"></script>
	<script src="<?php echo asset('resources/assets/js/jquery.bxslider.min.js'); ?>"></script>
	<?php /*<script type="text/javascript" src="<?php echo asset('resources/assets/js/fliplightbox.min.js'); ?>"></script>*/ ?>
        <script type="text/javascript" src="<?php echo asset('resources/assets/js/ajax.js'); ?>"></script>
<!--	<script src="<?php echo asset('resources/assets/js/functions.js'); ?>"></script>-->


        <script type="text/javascript">
        $(document).ready(function () {
            $('[name="user_role"]').val('<?php echo e(old('user_role')); ?>');         
        });

        $(document).ready(function(){
            var next = 1;
            $(".add-more").click(function(e){
                e.preventDefault();
                var addto = "#field" + next;
                var addRemove = "#field" + (next);
                next = next + 1;
                var newIn = '<input autocomplete="off" style="width: 90%; margin-bottom: 4%; display: inline-table;" class="input form-control" id="field' + next + '" name="class[]" type="text">';
                var newInput = $(newIn);
                var removeBtn = '<button id="remove' + (next - 1) + '" class="btn btn-danger remove-me" >-</button></div><div id="field">';
                var removeButton = $(removeBtn);
                $(addto).after(newInput);
                $(addRemove).after(removeButton);
                $("#field" + next).attr('data-source',$(addto).attr('data-source'));
                $("#count").val(next);

                $('.remove-me').click(function(e){
                    e.preventDefault();
                    var fieldNum = this.id.charAt(this.id.length-1);
                    var fieldID = "#field" + fieldNum;
                    $(this).remove();
                    $(fieldID).remove();
                });
            });



        });
        
        
        $(document).ready(function() {
        var max_fields      = 10; //maximum input boxes allowed
        var wrapper         = $(".input_fields_wrap1"); //Fields wrapper
        var add_button      = $(".add_field_button1"); //Add button ID
        
        var next = 1;
        var x = 1; //initlal text box count
        var addto = "#field1" + next;
        var addRemove = "#field1" + (next);
        next = next + 1;
        
        $(add_button).click(function(e){ //on add input button click
            e.preventDefault();
            if(x < max_fields){ //max input box allowed
                x++; //text box increment
                $(wrapper).append('<div style="padding: 7px 0px;   "><input type="text" name="class[]" class="form-control" style="width:80%; display:inline-block;"  required="required"/><a href="#" class="remove_field btn btn-danger" style="float:right">Remove</a></div>'); //add input box
            }
        });

        $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
            e.preventDefault(); $(this).parent('div').remove(); x--;
        })
});

 $(document).ready(function() {
        var max_fields      = 10; //maximum input boxes allowed
        var wrapper         = $(".input_fields_wrap"); //Fields wrapper
        var add_button      = $(".add_field_button"); //Add button ID
        
        var next = 1;
        var x = 1; //initlal text box count
        var addto = "#field" + next;
        var addRemove = "#field" + (next);
        next = next + 1;
        
        $(add_button).click(function(e){ //on add input button click
            e.preventDefault();
            if(x < max_fields){ //max input box allowed
                x++; //text box increment
                $(wrapper).append('<div style="padding: 7px 0px;   "><input type="text" name="class[]" class="form-control" style="width:80%; display:inline-block;"  required="required"/><a href="#" class="remove_field btn btn-danger" style="float:right">Remove</a></div>'); //add input box
            }
        });

        $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
            e.preventDefault(); $(this).parent('div').remove(); x--;
        })
});




 $(document).ready(function() {
        var max_fields      = 10; //maximum input boxes allowed
        var wrapper         = $(".input_fields_wrap_class"); //Fields wrapper
        var add_button      = $(".add_field_class"); //Add button ID
        
        var next = 1;
        var x = 1; //initlal text box count
        var addto = "#field" + next;
        var addRemove = "#field" + (next);
        next = next + 1;
        
        $(add_button).click(function(e){ //on add input button click
            e.preventDefault();
            if(x < max_fields){ //max input box allowed
                x++; //text box increment
                $(wrapper).append('<tr><td></td><td colspan="3"><input id="class_name" type="text" class="form-control" name="class_namex"></td><td><button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteCourse">Delete</button></td></tr>'); //add input box
            }
        });

        $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
            e.preventDefault(); $(this).parent('div').remove(); x--;
        })
});





//For Second step in admin

$(document).ready(function() {
        var max_fields      = 10; //maximum input boxes allowed
        var wrapper         = $(".input_fields_wrap2"); //Fields wrapper
        var add_button      = $(".add_field_button2"); //Add button ID
        
        var next = 1;
        var x = 1; //initlal text box count
        var addto = "#field" + next;
        var addRemove = "#field" + (next);
        next = next + 1;
        
        $(add_button).click(function(e){ //on add input button click
            e.preventDefault();
            if(x < max_fields){ //max input box allowed
                x++; //text box increment
                $(wrapper).append('<div class="form-group"><div class="col-md-5"><label for="password">Select Class:</label><select class="form-control" name="class_id[]"> <?php if(!empty(@$class_detail)): ?><?php foreach(@$class_detail as $row): ?><option value="<?php echo e($row->id); ?>"><?php echo e($row->class_name); ?></option><?php endforeach; ?>   <?php endif; ?> </select></div></div><div class="input_fields_wrap2 form-group" ><div class="col-md-6"><label for="password">Enter Course Name:</label><input type="text" name="course_name[]" style="width:70%; display:inline-block;" class="form-control" required="required"><button class="remove_field btn btn-danger btn-sm">Remove</button></div></div>');
                //add input box 
            }
        });

        $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
            e.preventDefault(); $(this).parent('div').remove(); x--;
        })
});
    $(".applyadmission").click(function() {
        document.getElementById("admission_model").innerHTML = this.value;
        document.getElementById("_c_h").value = this.id;
    });

        $(".course_details").click(function() {
            document.getElementById("admission_model1").innerHTML = this.value;
            document.getElementById("year_data").innerHTML = $(this).attr("data-course");
            document.getElementById("_cl_h").value = this.id;
            document.getElementById("_c_h").value = $(this).attr("data-ch");
        });
        
       
       
        
	</script>
	<script type="text/javascript">
        $(document).ready(function () {
            $('[name="user_role"]').val('<?php echo e(old('user_role')); ?>');
        });
	</script>
	<script type="text/javascript">
        $(function()
        {
            var startDate;
            var d = new Date();
            var open = false;
            $('#one_way').datetimepicker({
                allowInputToggle: true ,
                defaultDate: d,
                format: 'DD-MM-YYYY',
                minDate:d
            });
            
            var startDate;
            var d = new Date();
            var open = false;
            $('#date').datetimepicker({
                allowInputToggle: true ,                
                format: 'DD-MM-YYYY',              
            });

            //For Start Admisson
            var startDate;
            var d = new Date();
            var open = false;
            $('#start_ad').datetimepicker({
                allowInputToggle: true ,
                defaultDate: d,
                format: 'DD-MM-YYYY',
                minDate:d
            });

            //For End Admisson
            var startDate;
            var d = new Date();
            var open = false;
            $('#end_ad').datetimepicker({
                allowInputToggle: true ,
                defaultDate: d,
//        autoclose: true,
                format: 'DD-MM-YYYY',
                minDate:d
            });
        });



        $(function()
        {
            //For Start Admisson
            var startDate;
            var d = new Date();
            var open = false;
            $('#start_ad1').datetimepicker({
                allowInputToggle: true ,
                format: 'DD-MM-YYYY',
            });

            //For End Admisson
            var startDate;
            var d = new Date();
            var open = false;
            $('#end_ad1').datetimepicker({
                allowInputToggle: true ,
                format: 'DD-MM-YYYY',
            });
        });
        
        $(".course_delete").click(function (){
            var course_hash = $(this).data('c');
            $("#update_att").attr('data-id',course_hash);
        });        
	</script>
<?php echo $__env->yieldContent('pageFooterSpecificPlugin'); ?>

<?php echo $__env->yieldContent('pageFooterSpecificJS'); ?>