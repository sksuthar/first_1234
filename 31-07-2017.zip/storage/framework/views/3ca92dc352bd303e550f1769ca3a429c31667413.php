<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .form-group.required .control-label:after {
            content:"*";
            color:red;
        }
    </style>
    <div class="container">
        <div class="row center-back">
            <!-- ======================= Center Part ============================ -->
            <div class="col-sm-12" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                <div class="col-sm-12 span2">
                    <div class="home-back">
                        <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px;     margin-top: 15px;" align="center">
                            <img class="home-logo" width="40px" height="auto" src="<?php echo e(url('resources/assets/images/logo.jpg')); ?>">
                            <h3>Sinhgad Institute Of Technology and Management</h3>
                            <p>Approved By Director of General Civil</p>
                            <div align="center">
                                <p>Survey No. 111/1</p>
                                <p>Pune-Mumbai Bypass Highway, Warje</p>
                                <p>Pune, Maharashtra 411058</p>
                            </div>
                        </div>

                    </div>

                </div>

                <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/student/application_form/one','enctype' => 'multipart/form-data']); ?>

                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px; margin-top: 20px;">
                        <h4>Basic details</h4>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('f_name') ? ' has-error' : ''); ?>  required">
                    <div class="col-md-4">
                        <label class="control-label" for="password">Name(First):</label>
                        <input id="school_name" type="text" class="form-control" name="f_name">
                        <?php if($errors->has('f_name')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('f_name')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('address_1') ? ' has-error' : ''); ?>">
                    <div class="col-md-4">
                        <label for="password">Name(Middle):</label>
                        <input id="school_id" type="text" class="form-control" name="m_name" value="<?php echo e(@$temp_admin_email[0]['address_1']); ?>">
                        <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('address_1')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('address_1') ? ' has-error' : ''); ?>">
                    <div class="col-md-4">
                        <label for="password">Name(Last):</label>
                        <input id="school_id" type="text" class="form-control" name="l_name" value="<?php echo e(@$temp_admin_email[0]['address_1']); ?>">
                        <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('address_1')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('dob') ? ' has-error' : ''); ?> required">
                    <div class="col-md-4">
                        <label class="control-label" for="password">Date of Birth:</label>
                        <div class="input-group date " id="one_way">
                            <input type="text" name="dob" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                            <?php if($errors->has('dob')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('dob')); ?></strong>
                                </span>
                            <?php endif; ?>
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>

                        </div>

                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-4" align="center" style="margin-top: 28px;">
                        <label for="password">Type:</label>
                        <label class="radio-inline">
                            <input type="radio" name="type"><label>Male</label>
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="type"><label>Female</label>
                        </label>
                    </div>
                </div>



                <div class="form-group<?php echo e($errors->has('blood_gr') ? ' has-error' : ''); ?>">
                    <div class="col-md-4">
                        <label for="password">Blood Group:</label>
                        <input id="school_id" type="text" class="form-control" name="blood_group" value="<?php echo e(@$temp_admin_email[0]['city']); ?>">
                        <?php if($errors->has('school_name')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('city')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group<?php echo e($errors->has('nationality') ? ' has-error' : ''); ?> required">
                    <div class="col-md-4">
                        <label class="control-label" for="password">Nationality:</label>
                        <input id="school_id" type="text" class="form-control" name="nationality">
                        <?php if($errors->has('nationality')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('nationality')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group required">
                    <div class="col-md-4" align="center" style="margin-top: 28px;">
                        <label class="control-label" for="password">Marital Status:</label>
                        <label class="radio-inline">
                            <input type="radio" name="marital_status"><label>Married</label>
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="marital_status"><label>Unmarried</label>
                        </label>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('mobile') ? ' has-error' : ''); ?> required">
                    <div class="col-md-4">
                        <label class="control-label" for="password">Mobile No:</label>
                        <input id="school_name" type="text" class="form-control" name="mobile">
                        <?php if($errors->has('mobile')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('mobile')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                </div>

                    <div class="form-group<?php echo e($errors->has('father_name') ? ' has-error' : ''); ?>  required">
                        <div class="col-md-4">
                            <label class="control-label" for="password">Father name:</label>
                            <input id="school_name" type="text" class="form-control" name="father_name">
                            <?php if($errors->has('father_name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('father_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                        <div class="form-group">
                            <div class="col-md-4">
                                <label class="control-label" for="password">Occupation:</label>
                                <input id="school_name" type="text" class="form-control" name="f_occupation">
                            </div>
                        </div>

                            <div class="form-group<?php echo e($errors->has('mother_name') ? ' has-error' : ''); ?>  required">
                                <div class="col-md-4" style="    margin-left: 0.1%;">
                                    <label class="control-label" for="password">Mother name:</label>
                                    <input id="school_name" type="text" class="form-control" name="mother_name">
                                    <?php if($errors->has('mother_name')): ?>
                                        <span class="help-block">
                                    <strong><?php echo e($errors->first('mother_name')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                                <div class="form-group">
                                    <div class="col-md-4">
                                        <label class="control-label" for="password">Occupation:</label>
                                        <input id="school_name" type="text" class="form-control" name="m_occupation">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px; margin-top: 20px;">
                                        <h4>Postal Address</h4>
                                    </div>
                                </div>





                                <div class="form-group<?php echo e($errors->has('po_add_1') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-6">
                                        <label class="control-label" for="password">Address 1:</label>
                                        <input id="school_name" type="text" class="form-control" name="po_add_1">
                                        <?php if($errors->has('po_add_1')): ?>
                                            <span class="help-block">
                                                    <strong><?php echo e($errors->first('po_add_1')); ?></strong>
                                                </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-6">
                                        <label class="control-label" for="password">Address 2:</label>
                                        <input id="school_name" type="text" class="form-control" name="po_add_2" valu>
                                    </div>
                                </div>



                                <div class="form-group<?php echo e($errors->has('po_city') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-4">
                                        <label class="control-label" for="password">City:</label>
                                        <input id="school_name" type="text" class="form-control" name="po_city">
                                        <?php if($errors->has('po_city')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('po_city')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group<?php echo e($errors->has('po_state') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-4">
                                        <label class="control-label" for="password">State:</label>
                                        <input id="school_name" type="text" class="form-control" name="po_state">
                                        <?php if($errors->has('po_state')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('po_state')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group<?php echo e($errors->has('po_pin_code') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-4">
                                        <label class="control-label" for="password">Pin Code:</label>
                                        <input id="school_name" type="text" class="form-control" name="po_pin_code">
                                        <?php if($errors->has('po_pin_code')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('po_pin_code')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>





                                <div class="form-group">
                                    <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px; margin-top: 20px;">
                                        <h4>Permanent Address</h4>
                                    </div>
                                </div>
                                <div class="form-group<?php echo e($errors->has('pe_add_1') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-6">
                                        <label class="control-label" for="password">Address 1:</label>
                                        <input id="school_name" type="text" class="form-control" name="pe_add_1">
                                        <?php if($errors->has('pe_add_1')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('pe_add_1')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-6">
                                        <label class="control-label" for="password">Address 2:</label>
                                        <input id="school_name" type="text" class="form-control" name="pe_add_2">
                                    </div>
                                </div>


                                <div class="form-group<?php echo e($errors->has('pe_city') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-4">
                                        <label class="control-label" for="password">City:</label>
                                        <input id="school_name" type="text" class="form-control" name="pe_city">
                                        <?php if($errors->has('pe_city')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('pe_city')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group<?php echo e($errors->has('pe_state') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-4">
                                        <label class="control-label" for="password">State:</label>
                                        <input id="school_name" type="text" class="form-control" name="pe_state">
                                        <?php if($errors->has('pe_state')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('pe_state')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group<?php echo e($errors->has('pe_pin_code') ? ' has-error' : ''); ?>  required">
                                    <div class="col-md-4">
                                        <label class="control-label" for="password">Pin Code:</label>
                                        <input id="school_name" type="text" class="form-control" name="pe_pin_code">
                                        <?php if($errors->has('pe_pin_code')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('pe_pin_code')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                <div class="form-group">
                    <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px; margin-top: 20px;">
                        <h4>Last Academic Information</h4>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('school') ? ' has-error' : ''); ?>  required">
                    <div class="col-md-5">
                        <label class="control-label" for="password">School or Institite or University:</label>
                        <input id="school_name" type="text" class="form-control" name="school">
                        <?php if($errors->has('school')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('school')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('year') ? ' has-error' : ''); ?>  required">
                    <div class="col-md-3">
                        <label class="control-label" for="password">Year:</label>
                        <input id="school_name" type="text" class="form-control" name="year">
                        <?php if($errors->has('year')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('year')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('marks') ? ' has-error' : ''); ?>  required">
                    <div class="col-md-3">
                        <label class="control-label" for="password">Cgpa or % Obtained:</label>
                        <input id="school_name" type="text" class="form-control" name="marks">
                        <?php if($errors->has('marks')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('marks')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('photo') ? ' has-error' : ''); ?>  required">
                    <div class="col-md-3">
                        <label class="control-label" for="password">Upload Photo</label>
                        <input type="file" class="form-control" accept="image/*" name="photo" onchange="loadFile(event)">
                        <?php if($errors->has('photo')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('photo')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <img style="width:100%;" id="output"/>
                        <script>
                            var loadFile = function(event) {
                                var output = document.getElementById('output');
                                output.src = URL.createObjectURL(event.target.files[0]);
                            };
                        </script>
                    </div>
                </div>

                <div class="form-group" align="center">
                    <div class="col-md-12" style="    margin-top: 4%;">
                        <input type="submit" value="Apply" class="btn btn-success">
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div> <!-- close container ( center area) -->
    <script type="text/javascript">
        $('#affi').affix({
            offset: {
                top: $('header').height()
            }
        });
    </script>
    <style type="text/css">
        header {
            height:auto;
        }
        #affi.affix {
            position: fixed;
            top: 100px;
            width:277px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>