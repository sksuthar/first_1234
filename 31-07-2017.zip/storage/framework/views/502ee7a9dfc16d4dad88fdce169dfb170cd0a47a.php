<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Admission schools or colleges</title>
    <script src="<?php echo asset('resources/assets/js/jquery-2.1.1.min.js'); ?>"></script>
    <link href="<?php echo asset('resources/assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('resources/assets/css/bootstrap-datetimepicker.min.css'); ?>" rel="stylesheet">
    <?php /*<link rel="stylesheet" href="<?php echo asset('resources/assets/css/animate.css'); ?>">*/ ?>
    <?php /*<link rel="stylesheet" href="<?php echo asset('resources/assets/css/font-awesome.min.css'); ?>">*/ ?>
    <?php /*<link rel="stylesheet" href="<?php echo asset('resources/assets/css/jquery.bxslider.css'); ?>">*/ ?>
    <?php /*<link rel="stylesheet" type="text/css" href="<?php echo asset('resources/assets/css/normalize.css'); ?>" />*/ ?>
    <link rel="stylesheet" type="text/css" href="<?php echo asset('resources/assets/css/demo.css'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo asset('resources/assets/css/set1.css'); ?>" />
    <link href="<?php echo asset('resources/assets/css/overwrite.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('resources/assets/css/style.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('resources/assets/css/home_style.css'); ?>" rel="stylesheet">
     
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular-route.js"></script>
    <script src="<?php echo asset('resources/assets/js/app.js'); ?>" id="script-resource-10"></script>
    <script src="<?php echo asset('resources/assets/js/appcontroller.js'); ?>" id="script-resource-10"></script>
    <script type="text/javascript">
        var BASE_URL = "<?php echo e(url('/')); ?>";
    </script>
  </head>
  <body>            
            <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>           
            <?php echo $__env->yieldContent('content'); ?>  
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>      
    </body>
</html>