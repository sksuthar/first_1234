<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
    </style>
    <div class="container">
        <div class="row center-back">

            <div class="col-sm-3" style="border: 1px solid #DDD; margin-right: 15px; ">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/1")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Classes Details</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/2")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Course Details</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <a href="<?php echo e(url("/setting/tab/3")); ?>">
                            <div style="text-align: center; border-bottom: 1px solid #DDD; padding-top: 10px; padding-bottom: 10px;">
                                <p>Schoool / College Details</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>


            <div class="col-sm-8" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px;">
                    <h3>Classes Name</h3>
                </div>
                <div class="row">
                    <?php foreach(@$class_name as $key=>$row): ?>
                        <a href="<?php echo e(url()->current()."/class?option=1&class_h=".$row->class_hash); ?>">
                            <div class="col-sm-4 col-md-4" style="padding: 20px; border: 1px solid #ccc;">
                                <?php echo e($key+1); ?>.
                                <?php echo e($row->class_name); ?>

                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div> <!-- close container ( center area) -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>