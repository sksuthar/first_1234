<?php $__env->startSection('content'); ?>
<style type="text/css">
    .active-home a img{
        border-bottom:2px solid #4ca2f4;
    }
    .active-home a img:hover {
        opacity: 1 !important;
    }
     @media (min-width: 1200px)
    {
        .container-15-15 {
            width: 30em;
            margin-left: auto;
            margin-right: auto;
            margin-top: 9em;
        } 
    }
</style>
<div class="container-15-15">    
    <div class="col-sm-12" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
        <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px;">
            <h3>Add Course</h3>             
        </div>
              <?php echo Form::open(['name'=>'create', 'id'=>'create', 'files'=>true, 'method'=>'POST', 'url'=>'/school_college_details/step_two_process','enctype' => 'multipart/form-data']); ?>  
            <?php echo e(csrf_field()); ?>                 
             <div class="input_fields_wrap2 form-group">                                                                             
                <div class="form-group">                                           
                    <div class="col-md-12">
                         <label for="password">Enter Course Name:</label>
                            <input type="text" name="course_name[]" class="form-control" required="required">
                            <label>Example:- I-class,X-class, MCA,MBA</label>
                    </div>
                </div>
            </div>
            <div class="col-md-12" align="center" style="border-top: 1px solid #ccc; padding-top: 3%;     margin-top: 4%;">
                <a href="<?php echo e(url("/school_college_details/one")); ?>" class="btn btn-sm btn-warning">Back</a>
                    <input id="submit-btn" type="submit" value="Next" class="btn btn-primary btn-sm" name="submit-btn">
            </div>
       <?php echo Form::close(); ?>

    </div>             
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>