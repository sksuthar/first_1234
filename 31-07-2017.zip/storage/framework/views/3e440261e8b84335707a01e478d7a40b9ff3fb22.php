<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .active-home a img{
            border-bottom:2px solid #4ca2f4;
        }
        .active-home a img:hover {
            opacity: 1 !important;
        }
        .row2 {
            -moz-column-width: 400px;
            -webkit-column-width: 400px;
            -moz-column-gap: 15px;
            -webkit-column-gap: 15px;
        }
        .menu-category {
            display: inline-block;
            width: 100%;
            border: 1px solid #ddd;
            margin: 0 0 10px 0;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            border-radius: 2px;
            /* background: #FFF; */
            padding: 15px;
            color: #444;
        }
    </style>
    <div class="container">
        <div class="row center-back">
            <!-- ======================= Center Part ============================ -->
            <div class="col-sm-9" style="border: 1px solid #DDD; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); padding-bottom:15px; ">
                  <h3><?php echo e(@$temp_admin_email[0]['school_name']); ?>  College details</h3>
                <table class="table table-hover">
                    <tbody>
                      <tr>
                        <td>School or College Name:</td>
                        <td><?php echo e(@$temp_admin_email[0]['school_name']); ?></td>
                        <td></td>
                        <td></td>
                      </tr>
                      <tr>
                          <td><label>Address 1:</label></td>
                        <td><?php echo e(@$temp_admin_email[0]['address_1']); ?></td>
                        <td>Address 1:</td>
                        <td><?php echo e(@$temp_admin_email[0]['address_1']); ?></td>
                      </tr>
                      <tr>
                        <td>City :</td>
                        <td><?php echo e(@$temp_admin_email[0]['city']); ?></td>
                        <td>Pin Code :</td>
                        <td><?php echo e(@$temp_admin_email[0]['pin_code']); ?></td>
                      </tr>
                       <tr>
                        <td>City :</td>
                        <td><?php echo e(@$temp_admin_email[0]['city']); ?></td>
                        <td>Pin Code :</td>
                        <td><?php echo e(@$temp_admin_email[0]['pin_code']); ?></td>
                      </tr>
                       <tr>
                        <td>State :</td>
                        <td> <?php echo e(@$temp_admin_email[0]->getstate['state_name']); ?></td>
                        <td>Phone No 1 :</td>
                        <td><?php echo e(@$temp_admin_email[0]['phone_no1']); ?></td>
                      </tr>
                      <tr>
                        <td>Phone No 2 :</td>
                        <td><?php echo e(@$temp_admin_email[0]['phone_no2']); ?></td>
                        <td>Phone No 3 :</td>
                        <td><?php echo e(@$temp_admin_email[0]['phone_no3']); ?></td>
                      </tr>

                    </tbody>
                  </table>
                
                    <div class="form-group">
                    <div class="col-sm-12 col-md-12 col-lg-12 btm-bdr" style="  margin-bottom: 25px; margin-top: 20px;">
                        <h4>Classes details</h4>

                    </div>
                    </div>
                    <div class="form-group">
                        <?php if(@$classes_details): ?>
                            <?php $i = 1 ?>
                            <?php foreach(@$classes_details as $row): ?>
                                <div class="col-md-4" style="border: 1px solid #ccc; padding: 15px;">
                                    <?php echo e($i++); ?>.<?php echo e($row->class_name); ?>

                                    <a href="#" class="pull-right">
                                        <span class="glyphicon glyphicon-pencil"></span>
                                    </a>
                                    <?php $j =1 ?>
                                    <?php foreach(@$course_details as $key=>$value): ?>
                                        <?php if($value->class_id == $row->id): ?>
                                            <div class="input_fields_wrap" id="field">
                                                <div style="margin: 7px 0px;">
                                                    <?php echo e($j++); ?> . <?php echo e($value->course_name); ?>

                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?><br/>
                                    <button class="btn btn-warning btn-xs pull-right applyadmission" value="<?php echo e($row->class_name); ?>" id="<?php echo e($row->class_hash); ?>" data-toggle="modal" data-target="#myModal">Active Admission</button>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
            </div>
            <!-- ======================= Right Part ============================ -->

            <div class="col-sm-3 span3">
                <div>
                    <header>
                        <div class="box sb-right" style="background-color:#2cc16b; color:#fff; border:none;">
                            <span><i class="calendar icon"></i> Today</span>
                            <div style="margin-top:5px;">
                                <span style="font-size:18px;"><?php echo date("l, j F"); ?></span>
                            </div>
                        </div>

                    </header>
                    <div id="affi">
                        <div class="box">
                            <span style="color:#bbb;">My College</span>
                            <div style="margin-top:10px;" align="right">
                                <img style="margin-left:-10px; margin-bottom:10px;" src="assets/images/college.jpg" width="109%" height="auto">
                                <button class="btn btn-default btn-xs">Manage page</button>
                            </div>
                        </div>
                        <div class="box">
                            <p class="terms">sehooa &copy 2015</p>
                            <a class="a-tag terms" href="#">About</a>&nbsp
                            <a class="a-tag terms" href="#">Help</a>&nbsp
                            <a class="a-tag terms" href="#">Privace</a>&nbsp
                            <a class="a-tag terms" href="#">Terms</a>&nbsp
                            <a class="a-tag terms" href="#">Cookies</a>
                        </div>
                    </div>
                </div><!-- Fixed Div -->
            </div>
            <!-- ==== Close Right ====== -->
        </div>
    </div> <!-- close container ( center area) -->
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog" ng-app="wizboat-app">
            <!-- Modal content-->
            <div class="modal-content"  ng-controller="admission-apply-ctrl">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Activate Admission</h4>
                </div>
                <form class="form-horizontal" name="userForm" role="form" method="POST" ng-submit="admission_open()">
                <div class="modal-body">
                    <h4 id="admission_model"></h4>
                    <input id="_c_h" type="hidden" ng-model="app_a" value="">
                    <div class="row">
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <label class="control-label" for="password">Open Admission:</label>
                            <div class="input-group date " id="start_ad">
                                <input type="text" name="dob" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-6 col-lg-6">
                            <label class="control-label" for="password">End Admission:</label>
                            <div class="input-group date " id="end_ad">
                                <input type="text" name="dob" class="form-control ret input--textfield" id="firstd" autocomplete="off">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="submit" class="btn btn-success" value="Activate">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>